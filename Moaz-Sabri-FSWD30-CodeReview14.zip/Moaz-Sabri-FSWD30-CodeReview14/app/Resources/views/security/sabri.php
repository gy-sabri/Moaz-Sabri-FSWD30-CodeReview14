


{% block sidebar %}
    {{ parent() }}

    {{ show_source_code(_self) }}
{% endblock %}
