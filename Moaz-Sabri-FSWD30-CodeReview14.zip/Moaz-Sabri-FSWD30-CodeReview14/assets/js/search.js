import './jquery.instantSearch.js';

$(function() {
    $('.search-field').instantSearch({
        previewDelay: 100,
    });
});
