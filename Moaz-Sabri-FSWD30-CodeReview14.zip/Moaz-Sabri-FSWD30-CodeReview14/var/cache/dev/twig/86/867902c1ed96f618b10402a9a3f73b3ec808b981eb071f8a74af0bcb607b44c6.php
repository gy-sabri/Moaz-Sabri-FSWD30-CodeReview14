<?php

/* admin/blog/new.html.twig */
class __TwigTemplate_abcf488ec4799caa247b56cee536a0695f957ae6615846fd0a657c98d150f9cf extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("admin/layout.html.twig", "admin/blog/new.html.twig", 1);
        $this->blocks = array(
            'body_id' => array($this, 'block_body_id'),
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "admin/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1c1a29e1bf6be281f2bebf34e545a387c1746a9330f4fc3a64173738bb0b8ea1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1c1a29e1bf6be281f2bebf34e545a387c1746a9330f4fc3a64173738bb0b8ea1->enter($__internal_1c1a29e1bf6be281f2bebf34e545a387c1746a9330f4fc3a64173738bb0b8ea1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "admin/blog/new.html.twig"));

        $__internal_cd8905eda96c2eab4313e15f2348a9b5198e66596ec2dd2d5cc6d95ca92011df = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cd8905eda96c2eab4313e15f2348a9b5198e66596ec2dd2d5cc6d95ca92011df->enter($__internal_cd8905eda96c2eab4313e15f2348a9b5198e66596ec2dd2d5cc6d95ca92011df_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "admin/blog/new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_1c1a29e1bf6be281f2bebf34e545a387c1746a9330f4fc3a64173738bb0b8ea1->leave($__internal_1c1a29e1bf6be281f2bebf34e545a387c1746a9330f4fc3a64173738bb0b8ea1_prof);

        
        $__internal_cd8905eda96c2eab4313e15f2348a9b5198e66596ec2dd2d5cc6d95ca92011df->leave($__internal_cd8905eda96c2eab4313e15f2348a9b5198e66596ec2dd2d5cc6d95ca92011df_prof);

    }

    // line 3
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_8480923637d5838d4c572b72be7baa1d60634162ac54ef3670cdeeea7a8cc58b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8480923637d5838d4c572b72be7baa1d60634162ac54ef3670cdeeea7a8cc58b->enter($__internal_8480923637d5838d4c572b72be7baa1d60634162ac54ef3670cdeeea7a8cc58b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_19e4a46158302a0ff19ffeae0016baa83161bb8a73cfab9afab04bd918999914 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_19e4a46158302a0ff19ffeae0016baa83161bb8a73cfab9afab04bd918999914->enter($__internal_19e4a46158302a0ff19ffeae0016baa83161bb8a73cfab9afab04bd918999914_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        echo "admin_post_new";
        
        $__internal_19e4a46158302a0ff19ffeae0016baa83161bb8a73cfab9afab04bd918999914->leave($__internal_19e4a46158302a0ff19ffeae0016baa83161bb8a73cfab9afab04bd918999914_prof);

        
        $__internal_8480923637d5838d4c572b72be7baa1d60634162ac54ef3670cdeeea7a8cc58b->leave($__internal_8480923637d5838d4c572b72be7baa1d60634162ac54ef3670cdeeea7a8cc58b_prof);

    }

    // line 5
    public function block_main($context, array $blocks = array())
    {
        $__internal_52f3dd052acfd058bda8be1f061b85dba898efc0e07282f28effac9c3d66759c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_52f3dd052acfd058bda8be1f061b85dba898efc0e07282f28effac9c3d66759c->enter($__internal_52f3dd052acfd058bda8be1f061b85dba898efc0e07282f28effac9c3d66759c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_9e1b9d22d766949cb1983f429988cf5a782b899a68232893a0aaaec8fdb5378c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9e1b9d22d766949cb1983f429988cf5a782b899a68232893a0aaaec8fdb5378c->enter($__internal_9e1b9d22d766949cb1983f429988cf5a782b899a68232893a0aaaec8fdb5378c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 6
        echo "    <div class=\"container new-event\">
        <h1>";
        // line 7
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("title.post_new"), "html", null, true);
        echo "</h1>

        ";
        // line 9
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_start');
        echo "
            <div class=\"row\">
                <div class=\"col-md-6\">
                    ";
        // line 12
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "title", array()), 'row');
        echo "
                </div>
                <div class=\"col-md-6\">
                    ";
        // line 15
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "category", array()), 'row');
        echo "
                </div>
                <div class=\"col-md-6\">
                    ";
        // line 18
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "url", array()), 'row');
        echo "
                </div>
                <div class=\"col-md-6\">
                    ";
        // line 21
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "address", array()), 'row');
        echo "
                </div>
                <div class=\"col-md-12\">
                    ";
        // line 24
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "summary", array()), 'row');
        echo "
                </div>
                <div class=\"col-md-12\">
                    ";
        // line 27
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "content", array()), 'row');
        echo "
                </div>
                <div class=\"col-md-6\">
                    ";
        // line 30
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "fromdate", array()), 'row');
        echo "
                </div>
                <div class=\"col-md-6\">
                    ";
        // line 33
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "todate", array()), 'row');
        echo "
                </div>
                <div class=\"col-md-6\">
                    ";
        // line 36
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "publishedAt", array()), 'row');
        echo "
                </div>
                <div class=\"col-md-6\">
                    ";
        // line 39
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "tags", array()), 'row');
        echo "
                </div>
                
            </div>
            <button type=\"submit\" class=\"btn btn-primary\">
                <i class=\"fa fa-save\" aria-hidden=\"true\"></i> ";
        // line 44
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("label.create_post"), "html", null, true);
        echo "
            </button>
            ";
        // line 46
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "saveAndCreateNew", array()), 'widget', array("label" => "label.save_and_create_new", "attr" => array("class" => "btn btn-primary")));
        echo "
            <a href=\"";
        // line 47
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_post_index");
        echo "\" class=\"btn btn-link\">
                <i class=\"fa fa-list-alt\" aria-hidden=\"true\"></i> ";
        // line 48
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("action.back_to_list"), "html", null, true);
        echo "
            </a>
        ";
        // line 50
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_end');
        echo "
    </div>
";
        
        $__internal_9e1b9d22d766949cb1983f429988cf5a782b899a68232893a0aaaec8fdb5378c->leave($__internal_9e1b9d22d766949cb1983f429988cf5a782b899a68232893a0aaaec8fdb5378c_prof);

        
        $__internal_52f3dd052acfd058bda8be1f061b85dba898efc0e07282f28effac9c3d66759c->leave($__internal_52f3dd052acfd058bda8be1f061b85dba898efc0e07282f28effac9c3d66759c_prof);

    }

    public function getTemplateName()
    {
        return "admin/blog/new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  162 => 50,  157 => 48,  153 => 47,  149 => 46,  144 => 44,  136 => 39,  130 => 36,  124 => 33,  118 => 30,  112 => 27,  106 => 24,  100 => 21,  94 => 18,  88 => 15,  82 => 12,  76 => 9,  71 => 7,  68 => 6,  59 => 5,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'admin/layout.html.twig' %}

{% block body_id 'admin_post_new' %}

{% block main %}
    <div class=\"container new-event\">
        <h1>{{ 'title.post_new'|trans }}</h1>

        {{ form_start(form) }}
            <div class=\"row\">
                <div class=\"col-md-6\">
                    {{ form_row(form.title) }}
                </div>
                <div class=\"col-md-6\">
                    {{ form_row(form.category) }}
                </div>
                <div class=\"col-md-6\">
                    {{ form_row(form.url) }}
                </div>
                <div class=\"col-md-6\">
                    {{ form_row(form.address) }}
                </div>
                <div class=\"col-md-12\">
                    {{ form_row(form.summary) }}
                </div>
                <div class=\"col-md-12\">
                    {{ form_row(form.content) }}
                </div>
                <div class=\"col-md-6\">
                    {{ form_row(form.fromdate) }}
                </div>
                <div class=\"col-md-6\">
                    {{ form_row(form.todate) }}
                </div>
                <div class=\"col-md-6\">
                    {{ form_row(form.publishedAt) }}
                </div>
                <div class=\"col-md-6\">
                    {{ form_row(form.tags) }}
                </div>
                
            </div>
            <button type=\"submit\" class=\"btn btn-primary\">
                <i class=\"fa fa-save\" aria-hidden=\"true\"></i> {{ 'label.create_post'|trans }}
            </button>
            {{ form_widget(form.saveAndCreateNew, {label: 'label.save_and_create_new', attr: {class: 'btn btn-primary'}}) }}
            <a href=\"{{ path('admin_post_index') }}\" class=\"btn btn-link\">
                <i class=\"fa fa-list-alt\" aria-hidden=\"true\"></i> {{ 'action.back_to_list'|trans }}
            </a>
        {{ form_end(form) }}
    </div>
{% endblock %}
", "admin/blog/new.html.twig", "C:\\xampp\\htdocs\\Moaz-Sabri-FSWD30-CodeReview14\\app\\Resources\\views\\admin\\blog\\new.html.twig");
    }
}
