<?php

/* security/login.html.twig */
class __TwigTemplate_99daae5c8305299e16a0e549cae50052c40ebc669e54642b22c5bc5d39029120 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "security/login.html.twig", 1);
        $this->blocks = array(
            'body_id' => array($this, 'block_body_id'),
            'javascripts' => array($this, 'block_javascripts'),
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_92d5d7dc1007663950370b67f2c57b7bd02fd3e6a98e630e5d9dc2e90c22cbf3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_92d5d7dc1007663950370b67f2c57b7bd02fd3e6a98e630e5d9dc2e90c22cbf3->enter($__internal_92d5d7dc1007663950370b67f2c57b7bd02fd3e6a98e630e5d9dc2e90c22cbf3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "security/login.html.twig"));

        $__internal_9a7082874e0f39d63789c023fcd5c46a8d55a4dddf760445374e4e53c307389b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9a7082874e0f39d63789c023fcd5c46a8d55a4dddf760445374e4e53c307389b->enter($__internal_9a7082874e0f39d63789c023fcd5c46a8d55a4dddf760445374e4e53c307389b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "security/login.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_92d5d7dc1007663950370b67f2c57b7bd02fd3e6a98e630e5d9dc2e90c22cbf3->leave($__internal_92d5d7dc1007663950370b67f2c57b7bd02fd3e6a98e630e5d9dc2e90c22cbf3_prof);

        
        $__internal_9a7082874e0f39d63789c023fcd5c46a8d55a4dddf760445374e4e53c307389b->leave($__internal_9a7082874e0f39d63789c023fcd5c46a8d55a4dddf760445374e4e53c307389b_prof);

    }

    // line 2
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_16c7a52ca6b4382fac4157cad620aeb6c03c24c1ab1227d17bfff06525deb85d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_16c7a52ca6b4382fac4157cad620aeb6c03c24c1ab1227d17bfff06525deb85d->enter($__internal_16c7a52ca6b4382fac4157cad620aeb6c03c24c1ab1227d17bfff06525deb85d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_591ba1c11bd6aeb6dc9363128534d3d0254d5136e4fbaacb982239759bc529ec = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_591ba1c11bd6aeb6dc9363128534d3d0254d5136e4fbaacb982239759bc529ec->enter($__internal_591ba1c11bd6aeb6dc9363128534d3d0254d5136e4fbaacb982239759bc529ec_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        echo "login";
        
        $__internal_591ba1c11bd6aeb6dc9363128534d3d0254d5136e4fbaacb982239759bc529ec->leave($__internal_591ba1c11bd6aeb6dc9363128534d3d0254d5136e4fbaacb982239759bc529ec_prof);

        
        $__internal_16c7a52ca6b4382fac4157cad620aeb6c03c24c1ab1227d17bfff06525deb85d->leave($__internal_16c7a52ca6b4382fac4157cad620aeb6c03c24c1ab1227d17bfff06525deb85d_prof);

    }

    // line 3
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_849f966b4e160cddfbf063921215415f452cfeaaf13b1fcd1bf7b30dc962c2dd = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_849f966b4e160cddfbf063921215415f452cfeaaf13b1fcd1bf7b30dc962c2dd->enter($__internal_849f966b4e160cddfbf063921215415f452cfeaaf13b1fcd1bf7b30dc962c2dd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_74fa908807c41fbe2fd7ce88dcbd0465ff4e70ea9b39b1eca5d96fe302374142 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_74fa908807c41fbe2fd7ce88dcbd0465ff4e70ea9b39b1eca5d96fe302374142->enter($__internal_74fa908807c41fbe2fd7ce88dcbd0465ff4e70ea9b39b1eca5d96fe302374142_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 4
        echo "        ";
        $this->displayParentBlock("javascripts", $context, $blocks);
        echo "
        <script src=\"";
        // line 5
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("build/js/login.js"), "html", null, true);
        echo "\"></script>
    ";
        
        $__internal_74fa908807c41fbe2fd7ce88dcbd0465ff4e70ea9b39b1eca5d96fe302374142->leave($__internal_74fa908807c41fbe2fd7ce88dcbd0465ff4e70ea9b39b1eca5d96fe302374142_prof);

        
        $__internal_849f966b4e160cddfbf063921215415f452cfeaaf13b1fcd1bf7b30dc962c2dd->leave($__internal_849f966b4e160cddfbf063921215415f452cfeaaf13b1fcd1bf7b30dc962c2dd_prof);

    }

    // line 8
    public function block_main($context, array $blocks = array())
    {
        $__internal_ed2b6b6785cbd926ae208570d231c138189cd97babf095aa7ff5a67377933e7f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ed2b6b6785cbd926ae208570d231c138189cd97babf095aa7ff5a67377933e7f->enter($__internal_ed2b6b6785cbd926ae208570d231c138189cd97babf095aa7ff5a67377933e7f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_f5ed9db8bcdaf7dcfeed6c391b53122e37b25738bdbaa531a4eb063144ad371d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f5ed9db8bcdaf7dcfeed6c391b53122e37b25738bdbaa531a4eb063144ad371d->enter($__internal_f5ed9db8bcdaf7dcfeed6c391b53122e37b25738bdbaa531a4eb063144ad371d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 9
        echo "        <center class=\"container\">
            ";
        // line 10
        if (($context["error"] ?? $this->getContext($context, "error"))) {
            // line 11
            echo "                <div class=\"alert alert-danger\">
                    ";
            // line 12
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans($this->getAttribute(($context["error"] ?? $this->getContext($context, "error")), "messageKey", array()), $this->getAttribute(($context["error"] ?? $this->getContext($context, "error")), "messageData", array()), "security"), "html", null, true);
            echo "
                </div>
            ";
        }
        // line 15
        echo "
            <div class=\"well text-left w-50\">
                <form action=\"";
        // line 17
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("security_login");
        echo "\" method=\"post\">
                    <legend><i class=\"fa fa-lock\" aria-hidden=\"true\"></i> ";
        // line 18
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("title.login"), "html", null, true);
        echo "</legend>
                    <div class=\"form-group\">
                        <label for=\"username\">";
        // line 20
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("label.username"), "html", null, true);
        echo " admin</label>
                        <input type=\"text\" id=\"username\" name=\"_username\" value=\"";
        // line 21
        echo twig_escape_filter($this->env, ($context["last_username"] ?? $this->getContext($context, "last_username")), "html", null, true);
        echo "\" class=\"form-control\"/>
                    </div>
                    <div class=\"form-group\">
                        <label for=\"password\">";
        // line 24
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("label.password"), "html", null, true);
        echo " 123456</label>
                        <input type=\"password\" id=\"password\" name=\"_password\" class=\"form-control\" />
                    </div>
                    <input type=\"hidden\" name=\"_csrf_token\" value=\"";
        // line 27
        echo twig_escape_filter($this->env, $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderCsrfToken("authenticate"), "html", null, true);
        echo "\"/><br>
                    <button type=\"submit\" class=\"btn btn-primary\">
                        <i class=\"fa fa-sign-in\" aria-hidden=\"true\"></i> ";
        // line 29
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("action.sign_in"), "html", null, true);
        echo "
                    </button>
                </form>
            </div>
        </center>
    ";
        
        $__internal_f5ed9db8bcdaf7dcfeed6c391b53122e37b25738bdbaa531a4eb063144ad371d->leave($__internal_f5ed9db8bcdaf7dcfeed6c391b53122e37b25738bdbaa531a4eb063144ad371d_prof);

        
        $__internal_ed2b6b6785cbd926ae208570d231c138189cd97babf095aa7ff5a67377933e7f->leave($__internal_ed2b6b6785cbd926ae208570d231c138189cd97babf095aa7ff5a67377933e7f_prof);

    }

    public function getTemplateName()
    {
        return "security/login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  143 => 29,  138 => 27,  132 => 24,  126 => 21,  122 => 20,  117 => 18,  113 => 17,  109 => 15,  103 => 12,  100 => 11,  98 => 10,  95 => 9,  86 => 8,  74 => 5,  69 => 4,  60 => 3,  42 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}
{% block body_id 'login' %}
    {% block javascripts %}
        {{ parent() }}
        <script src=\"{{ asset('build/js/login.js') }}\"></script>
    {% endblock %}

    {% block main %}
        <center class=\"container\">
            {% if error %}
                <div class=\"alert alert-danger\">
                    {{ error.messageKey|trans(error.messageData, 'security') }}
                </div>
            {% endif %}

            <div class=\"well text-left w-50\">
                <form action=\"{{ path('security_login') }}\" method=\"post\">
                    <legend><i class=\"fa fa-lock\" aria-hidden=\"true\"></i> {{ 'title.login'|trans }}</legend>
                    <div class=\"form-group\">
                        <label for=\"username\">{{ 'label.username'|trans }} admin</label>
                        <input type=\"text\" id=\"username\" name=\"_username\" value=\"{{ last_username }}\" class=\"form-control\"/>
                    </div>
                    <div class=\"form-group\">
                        <label for=\"password\">{{ 'label.password'|trans }} 123456</label>
                        <input type=\"password\" id=\"password\" name=\"_password\" class=\"form-control\" />
                    </div>
                    <input type=\"hidden\" name=\"_csrf_token\" value=\"{{ csrf_token('authenticate') }}\"/><br>
                    <button type=\"submit\" class=\"btn btn-primary\">
                        <i class=\"fa fa-sign-in\" aria-hidden=\"true\"></i> {{ 'action.sign_in'|trans }}
                    </button>
                </form>
            </div>
        </center>
    {% endblock %}


", "security/login.html.twig", "C:\\xampp\\htdocs\\symfony_demo\\app\\Resources\\views\\security\\login.html.twig");
    }
}
