<?php

/* blog/_rss.html.twig */
class __TwigTemplate_8ce8551a21b978e1225194fad324fb55af47e453a34b33d9b063deb3326d83e9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_355939de9145b006e5aad03afe03ae6ea4365cf10c041c2c73a511edad308a77 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_355939de9145b006e5aad03afe03ae6ea4365cf10c041c2c73a511edad308a77->enter($__internal_355939de9145b006e5aad03afe03ae6ea4365cf10c041c2c73a511edad308a77_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "blog/_rss.html.twig"));

        $__internal_08d1dfb7503c5603bdad2aa2be0ae876fb0c25d40cd6256bee7e7c4ddfe1c29b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_08d1dfb7503c5603bdad2aa2be0ae876fb0c25d40cd6256bee7e7c4ddfe1c29b->enter($__internal_08d1dfb7503c5603bdad2aa2be0ae876fb0c25d40cd6256bee7e7c4ddfe1c29b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "blog/_rss.html.twig"));

        // line 1
        echo "<div class=\"section rss\">
    <a href=\"";
        // line 2
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("blog_rss");
        echo "\">
        <i class=\"fa fa-rss\" aria-hidden=\"true\"></i> ";
        // line 3
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("menu.rss"), "html", null, true);
        echo "
    </a>
</div>
";
        
        $__internal_355939de9145b006e5aad03afe03ae6ea4365cf10c041c2c73a511edad308a77->leave($__internal_355939de9145b006e5aad03afe03ae6ea4365cf10c041c2c73a511edad308a77_prof);

        
        $__internal_08d1dfb7503c5603bdad2aa2be0ae876fb0c25d40cd6256bee7e7c4ddfe1c29b->leave($__internal_08d1dfb7503c5603bdad2aa2be0ae876fb0c25d40cd6256bee7e7c4ddfe1c29b_prof);

    }

    public function getTemplateName()
    {
        return "blog/_rss.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  32 => 3,  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"section rss\">
    <a href=\"{{ path('blog_rss') }}\">
        <i class=\"fa fa-rss\" aria-hidden=\"true\"></i> {{ 'menu.rss'|trans }}
    </a>
</div>
", "blog/_rss.html.twig", "C:\\xampp\\htdocs\\symfony_demo\\app\\Resources\\views\\blog\\_rss.html.twig");
    }
}
