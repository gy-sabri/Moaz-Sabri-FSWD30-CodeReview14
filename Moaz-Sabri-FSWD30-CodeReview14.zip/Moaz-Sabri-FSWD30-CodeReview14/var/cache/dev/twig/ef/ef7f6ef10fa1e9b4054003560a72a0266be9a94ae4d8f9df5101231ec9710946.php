<?php

/* admin/blog/show.html.twig */
class __TwigTemplate_923268e7cad5db107270afb259ea107dbc79665a45e0b31c89fd190cff11d98d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("admin/layout.html.twig", "admin/blog/show.html.twig", 1);
        $this->blocks = array(
            'body_id' => array($this, 'block_body_id'),
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "admin/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_90eb63ac5b782c04e44c5573718ffee816d7b2e45e4494f6f53f3c09e256ef54 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_90eb63ac5b782c04e44c5573718ffee816d7b2e45e4494f6f53f3c09e256ef54->enter($__internal_90eb63ac5b782c04e44c5573718ffee816d7b2e45e4494f6f53f3c09e256ef54_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "admin/blog/show.html.twig"));

        $__internal_6c63342e8b8e266ea588fe9fedc067ed714840faaa84b12142be361ad4ac5bd0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6c63342e8b8e266ea588fe9fedc067ed714840faaa84b12142be361ad4ac5bd0->enter($__internal_6c63342e8b8e266ea588fe9fedc067ed714840faaa84b12142be361ad4ac5bd0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "admin/blog/show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_90eb63ac5b782c04e44c5573718ffee816d7b2e45e4494f6f53f3c09e256ef54->leave($__internal_90eb63ac5b782c04e44c5573718ffee816d7b2e45e4494f6f53f3c09e256ef54_prof);

        
        $__internal_6c63342e8b8e266ea588fe9fedc067ed714840faaa84b12142be361ad4ac5bd0->leave($__internal_6c63342e8b8e266ea588fe9fedc067ed714840faaa84b12142be361ad4ac5bd0_prof);

    }

    // line 3
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_12900ac539764869426eb20a6429936e62bb2bff78db9daf1ecf9ddf95723059 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_12900ac539764869426eb20a6429936e62bb2bff78db9daf1ecf9ddf95723059->enter($__internal_12900ac539764869426eb20a6429936e62bb2bff78db9daf1ecf9ddf95723059_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_2b4d2fd026b5d32d998dfb4b931f6f02e8ccf10ec8117ca6f300f7a4f6872bfc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2b4d2fd026b5d32d998dfb4b931f6f02e8ccf10ec8117ca6f300f7a4f6872bfc->enter($__internal_2b4d2fd026b5d32d998dfb4b931f6f02e8ccf10ec8117ca6f300f7a4f6872bfc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        echo "admin_post_show";
        
        $__internal_2b4d2fd026b5d32d998dfb4b931f6f02e8ccf10ec8117ca6f300f7a4f6872bfc->leave($__internal_2b4d2fd026b5d32d998dfb4b931f6f02e8ccf10ec8117ca6f300f7a4f6872bfc_prof);

        
        $__internal_12900ac539764869426eb20a6429936e62bb2bff78db9daf1ecf9ddf95723059->leave($__internal_12900ac539764869426eb20a6429936e62bb2bff78db9daf1ecf9ddf95723059_prof);

    }

    // line 5
    public function block_main($context, array $blocks = array())
    {
        $__internal_cce62a7c1c1323d9dcf7e7b38fe1f6a428e0de1b5e1235049994cf4d0878a228 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cce62a7c1c1323d9dcf7e7b38fe1f6a428e0de1b5e1235049994cf4d0878a228->enter($__internal_cce62a7c1c1323d9dcf7e7b38fe1f6a428e0de1b5e1235049994cf4d0878a228_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_0fb5dde8878578519645e48811bbd7334fcbd366c7f4c158efa5458fda782486 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0fb5dde8878578519645e48811bbd7334fcbd366c7f4c158efa5458fda782486->enter($__internal_0fb5dde8878578519645e48811bbd7334fcbd366c7f4c158efa5458fda782486_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 6
        echo "    <div class=\"container\">
        <h4>";
        // line 7
        echo twig_escape_filter($this->env, $this->getAttribute(($context["post"] ?? $this->getContext($context, "post")), "category", array()), "html", null, true);
        echo "</h4>
        <h1>";
        // line 8
        echo twig_escape_filter($this->env, $this->getAttribute(($context["post"] ?? $this->getContext($context, "post")), "title", array()), "html", null, true);
        echo "</h1>
        <div>
            <img src=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->getAttribute(($context["post"] ?? $this->getContext($context, "post")), "url", array()), "html", null, true);
        echo "\" class=\"w-100\">
        </div>
        <p class=\"post-metadata\">
            <div>
                <span class=\"metadata\"><i class=\"fa fa-calendar\"></i> Date ";
        // line 14
        echo twig_escape_filter($this->env, twig_localized_date_filter($this->env, $this->getAttribute(($context["post"] ?? $this->getContext($context, "post")), "publishedAt", array()), "long", "medium", null, "UTC"), "html", null, true);
        echo "</span>
                <span class=\"metadata\"><i class=\"fa fa-calendar\"></i> From ";
        // line 15
        echo twig_escape_filter($this->env, twig_localized_date_filter($this->env, $this->getAttribute(($context["post"] ?? $this->getContext($context, "post")), "fromdate", array()), "long", "medium", null, "UTC"), "html", null, true);
        echo "</span>
                <span class=\"metadata\"><i class=\"fa fa-calendar\"></i> To ";
        // line 16
        echo twig_escape_filter($this->env, twig_localized_date_filter($this->env, $this->getAttribute(($context["post"] ?? $this->getContext($context, "post")), "todate", array()), "long", "medium", null, "UTC"), "html", null, true);
        echo "</span>
            </div>
            <span class=\"metadata\"><i class=\"fa fa-user\"></i> ";
        // line 18
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["post"] ?? $this->getContext($context, "post")), "author", array()), "fullName", array()), "html", null, true);
        echo "</span>
            <span class=\"metadata\"><i class=\"fa fa-user\"></i> ";
        // line 19
        echo twig_escape_filter($this->env, $this->getAttribute(($context["post"] ?? $this->getContext($context, "post")), "address", array()), "html", null, true);
        echo "</span>
        </p>

        <div class=\"w-50\">
            <p class=\"m-b-0\"><strong>";
        // line 23
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("label.summary"), "html", null, true);
        echo "</strong>: ";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["post"] ?? $this->getContext($context, "post")), "summary", array()), "html", null, true);
        echo "</p>
        </div>

        <div class=\"w-75\">
            ";
        // line 27
        echo $this->env->getExtension('AppBundle\Twig\AppExtension')->markdownToHtml($this->getAttribute(($context["post"] ?? $this->getContext($context, "post")), "content", array()));
        echo "
        </div>
        ";
        // line 29
        echo twig_include($this->env, $context, "blog/_post_tags.html.twig");
        echo "

        <hr>
        <div class=\"row\">
            <div class=\"section col-sm-6\">
                <a href=\"";
        // line 34
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_post_edit", array("id" => $this->getAttribute(($context["post"] ?? $this->getContext($context, "post")), "id", array()))), "html", null, true);
        echo "\" class=\"btn btn-lg btn-block btn-success\">
                    <i class=\"fa fa-edit\" aria-hidden=\"true\"></i> ";
        // line 35
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("action.edit_contents"), "html", null, true);
        echo "
                </a>
            </div>
            <div class=\"section col-sm-6\">
                <div class=\"section\">
                    ";
        // line 40
        echo twig_include($this->env, $context, "admin/blog/_delete_form.html.twig", array("post" => ($context["post"] ?? $this->getContext($context, "post"))), false);
        echo "
                </div>
            </div>
        </div>
    </div>

";
        
        $__internal_0fb5dde8878578519645e48811bbd7334fcbd366c7f4c158efa5458fda782486->leave($__internal_0fb5dde8878578519645e48811bbd7334fcbd366c7f4c158efa5458fda782486_prof);

        
        $__internal_cce62a7c1c1323d9dcf7e7b38fe1f6a428e0de1b5e1235049994cf4d0878a228->leave($__internal_cce62a7c1c1323d9dcf7e7b38fe1f6a428e0de1b5e1235049994cf4d0878a228_prof);

    }

    public function getTemplateName()
    {
        return "admin/blog/show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  145 => 40,  137 => 35,  133 => 34,  125 => 29,  120 => 27,  111 => 23,  104 => 19,  100 => 18,  95 => 16,  91 => 15,  87 => 14,  80 => 10,  75 => 8,  71 => 7,  68 => 6,  59 => 5,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'admin/layout.html.twig' %}

{% block body_id 'admin_post_show' %}

{% block main %}
    <div class=\"container\">
        <h4>{{ post.category }}</h4>
        <h1>{{ post.title }}</h1>
        <div>
            <img src=\"{{ post.url }}\" class=\"w-100\">
        </div>
        <p class=\"post-metadata\">
            <div>
                <span class=\"metadata\"><i class=\"fa fa-calendar\"></i> Date {{ post.publishedAt|localizeddate('long', 'medium', null, 'UTC') }}</span>
                <span class=\"metadata\"><i class=\"fa fa-calendar\"></i> From {{ post.fromdate|localizeddate('long', 'medium', null, 'UTC') }}</span>
                <span class=\"metadata\"><i class=\"fa fa-calendar\"></i> To {{ post.todate|localizeddate('long', 'medium', null, 'UTC') }}</span>
            </div>
            <span class=\"metadata\"><i class=\"fa fa-user\"></i> {{ post.author.fullName }}</span>
            <span class=\"metadata\"><i class=\"fa fa-user\"></i> {{ post.address }}</span>
        </p>

        <div class=\"w-50\">
            <p class=\"m-b-0\"><strong>{{ 'label.summary'|trans }}</strong>: {{ post.summary }}</p>
        </div>

        <div class=\"w-75\">
            {{ post.content|md2html }}
        </div>
        {{ include('blog/_post_tags.html.twig') }}

        <hr>
        <div class=\"row\">
            <div class=\"section col-sm-6\">
                <a href=\"{{ path('admin_post_edit', {id: post.id}) }}\" class=\"btn btn-lg btn-block btn-success\">
                    <i class=\"fa fa-edit\" aria-hidden=\"true\"></i> {{ 'action.edit_contents'|trans }}
                </a>
            </div>
            <div class=\"section col-sm-6\">
                <div class=\"section\">
                    {{ include('admin/blog/_delete_form.html.twig', {post: post}, with_context = false) }}
                </div>
            </div>
        </div>
    </div>

{% endblock %}
", "admin/blog/show.html.twig", "C:\\xampp\\htdocs\\Moaz-Sabri-FSWD30-CodeReview14\\app\\Resources\\views\\admin\\blog\\show.html.twig");
    }
}
