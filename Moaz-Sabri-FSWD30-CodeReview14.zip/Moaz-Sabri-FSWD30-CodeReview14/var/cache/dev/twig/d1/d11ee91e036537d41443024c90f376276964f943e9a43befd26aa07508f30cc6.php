<?php

/* form/fields.html.twig */
class __TwigTemplate_e1c89eff5151336b55d5acadd5567eaa087720c69063de084814cc5acb9c76ab extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'date_time_picker_widget' => array($this, 'block_date_time_picker_widget'),
            'tags_input_widget' => array($this, 'block_tags_input_widget'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2422ed72e7523aac6ed65d89317a2dc19de4b24f6676820b0736326c0d4c6e8e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2422ed72e7523aac6ed65d89317a2dc19de4b24f6676820b0736326c0d4c6e8e->enter($__internal_2422ed72e7523aac6ed65d89317a2dc19de4b24f6676820b0736326c0d4c6e8e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "form/fields.html.twig"));

        $__internal_00d593fc68aeb04464d69823a66af051bbb0aa58f92246f720ff19cd9822c2cf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_00d593fc68aeb04464d69823a66af051bbb0aa58f92246f720ff19cd9822c2cf->enter($__internal_00d593fc68aeb04464d69823a66af051bbb0aa58f92246f720ff19cd9822c2cf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "form/fields.html.twig"));

        // line 9
        echo "
";
        // line 10
        $this->displayBlock('date_time_picker_widget', $context, $blocks);
        // line 18
        echo "
";
        // line 19
        $this->displayBlock('tags_input_widget', $context, $blocks);
        
        $__internal_2422ed72e7523aac6ed65d89317a2dc19de4b24f6676820b0736326c0d4c6e8e->leave($__internal_2422ed72e7523aac6ed65d89317a2dc19de4b24f6676820b0736326c0d4c6e8e_prof);

        
        $__internal_00d593fc68aeb04464d69823a66af051bbb0aa58f92246f720ff19cd9822c2cf->leave($__internal_00d593fc68aeb04464d69823a66af051bbb0aa58f92246f720ff19cd9822c2cf_prof);

    }

    // line 10
    public function block_date_time_picker_widget($context, array $blocks = array())
    {
        $__internal_35dcb7e6994c0fb14bcd498d58780202bf614c9eac068382f97884f8b28aadc6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_35dcb7e6994c0fb14bcd498d58780202bf614c9eac068382f97884f8b28aadc6->enter($__internal_35dcb7e6994c0fb14bcd498d58780202bf614c9eac068382f97884f8b28aadc6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "date_time_picker_widget"));

        $__internal_5797a6396fed5a730c596ec3d20c13c7a251939309e3dc6251fb0fa41a207134 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5797a6396fed5a730c596ec3d20c13c7a251939309e3dc6251fb0fa41a207134->enter($__internal_5797a6396fed5a730c596ec3d20c13c7a251939309e3dc6251fb0fa41a207134_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "date_time_picker_widget"));

        // line 11
        echo "    <div class=\"input-group date\" data-toggle=\"datetimepicker\">
        ";
        // line 12
        $this->displayBlock("datetime_widget", $context, $blocks);
        echo "
        <span class=\"input-group-addon\">
            <span class=\"fa fa-calendar\" aria-hidden=\"true\"></span>
        </span>
    </div>
";
        
        $__internal_5797a6396fed5a730c596ec3d20c13c7a251939309e3dc6251fb0fa41a207134->leave($__internal_5797a6396fed5a730c596ec3d20c13c7a251939309e3dc6251fb0fa41a207134_prof);

        
        $__internal_35dcb7e6994c0fb14bcd498d58780202bf614c9eac068382f97884f8b28aadc6->leave($__internal_35dcb7e6994c0fb14bcd498d58780202bf614c9eac068382f97884f8b28aadc6_prof);

    }

    // line 19
    public function block_tags_input_widget($context, array $blocks = array())
    {
        $__internal_008c9ff952c11ce881b093257b0771d8f382e6da6c8625332c4868650da54baa = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_008c9ff952c11ce881b093257b0771d8f382e6da6c8625332c4868650da54baa->enter($__internal_008c9ff952c11ce881b093257b0771d8f382e6da6c8625332c4868650da54baa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "tags_input_widget"));

        $__internal_119c49fd099aeaa2bb26d7deb2b5cf9bea6af5e313e6b909793bafece69c9206 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_119c49fd099aeaa2bb26d7deb2b5cf9bea6af5e313e6b909793bafece69c9206->enter($__internal_119c49fd099aeaa2bb26d7deb2b5cf9bea6af5e313e6b909793bafece69c9206_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "tags_input_widget"));

        // line 20
        echo "    <div class=\"input-group\">
        ";
        // line 21
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget', array("attr" => array("data-toggle" => "tagsinput", "data-tags" => twig_jsonencode_filter(($context["tags"] ?? $this->getContext($context, "tags"))))));
        echo "
        <span class=\"input-group-addon\">
            <span class=\"fa fa-tags\" aria-hidden=\"true\"></span>
        </span>
    </div>
";
        
        $__internal_119c49fd099aeaa2bb26d7deb2b5cf9bea6af5e313e6b909793bafece69c9206->leave($__internal_119c49fd099aeaa2bb26d7deb2b5cf9bea6af5e313e6b909793bafece69c9206_prof);

        
        $__internal_008c9ff952c11ce881b093257b0771d8f382e6da6c8625332c4868650da54baa->leave($__internal_008c9ff952c11ce881b093257b0771d8f382e6da6c8625332c4868650da54baa_prof);

    }

    public function getTemplateName()
    {
        return "form/fields.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  85 => 21,  82 => 20,  73 => 19,  57 => 12,  54 => 11,  45 => 10,  35 => 19,  32 => 18,  30 => 10,  27 => 9,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#
   Each field type is rendered by a template fragment, which is determined
   by the name of your form type class (DateTimePickerType -> date_time_picker)
   and the suffix \"_widget\". This can be controlled by overriding getBlockPrefix()
   in DateTimePickerType.

   See https://symfony.com/doc/current/cookbook/form/create_custom_field_type.html#creating-a-template-for-the-field
#}

{% block date_time_picker_widget %}
    <div class=\"input-group date\" data-toggle=\"datetimepicker\">
        {{ block('datetime_widget') }}
        <span class=\"input-group-addon\">
            <span class=\"fa fa-calendar\" aria-hidden=\"true\"></span>
        </span>
    </div>
{% endblock %}

{% block tags_input_widget %}
    <div class=\"input-group\">
        {{ form_widget(form, {'attr': {'data-toggle': 'tagsinput', 'data-tags': tags|json_encode}}) }}
        <span class=\"input-group-addon\">
            <span class=\"fa fa-tags\" aria-hidden=\"true\"></span>
        </span>
    </div>
{% endblock %}
", "form/fields.html.twig", "C:\\xampp\\htdocs\\symfony_demo\\app\\Resources\\views\\form\\fields.html.twig");
    }
}
