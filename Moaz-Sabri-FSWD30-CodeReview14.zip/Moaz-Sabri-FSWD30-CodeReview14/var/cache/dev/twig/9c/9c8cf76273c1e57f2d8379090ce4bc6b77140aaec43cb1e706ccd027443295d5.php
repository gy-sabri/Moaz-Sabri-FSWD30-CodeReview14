<?php

/* default/homepage.html.twig */
class __TwigTemplate_0e6abbb2f34f01d0cfa01b02591a31c722b7f31f6f150a0ddb9c7b54a37f8a13 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "default/homepage.html.twig", 1);
        $this->blocks = array(
            'body_id' => array($this, 'block_body_id'),
            'header' => array($this, 'block_header'),
            'body' => array($this, 'block_body'),
            'header_navigation_links' => array($this, 'block_header_navigation_links'),
            'footer' => array($this, 'block_footer'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_50559e2dbac00b768cf6c1629b7e47664e4db48eb13a939d282ecbc5c8b809e4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_50559e2dbac00b768cf6c1629b7e47664e4db48eb13a939d282ecbc5c8b809e4->enter($__internal_50559e2dbac00b768cf6c1629b7e47664e4db48eb13a939d282ecbc5c8b809e4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/homepage.html.twig"));

        $__internal_53cf4382c319080b3af190cb1437a6cbbc885f8d7536aab37321f1b912650524 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_53cf4382c319080b3af190cb1437a6cbbc885f8d7536aab37321f1b912650524->enter($__internal_53cf4382c319080b3af190cb1437a6cbbc885f8d7536aab37321f1b912650524_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/homepage.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_50559e2dbac00b768cf6c1629b7e47664e4db48eb13a939d282ecbc5c8b809e4->leave($__internal_50559e2dbac00b768cf6c1629b7e47664e4db48eb13a939d282ecbc5c8b809e4_prof);

        
        $__internal_53cf4382c319080b3af190cb1437a6cbbc885f8d7536aab37321f1b912650524->leave($__internal_53cf4382c319080b3af190cb1437a6cbbc885f8d7536aab37321f1b912650524_prof);

    }

    // line 3
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_aecd3f773d26715b16f6c25f7f0bc107d30017efd92ca318b2cd4f519fcb1566 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_aecd3f773d26715b16f6c25f7f0bc107d30017efd92ca318b2cd4f519fcb1566->enter($__internal_aecd3f773d26715b16f6c25f7f0bc107d30017efd92ca318b2cd4f519fcb1566_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_96b0f79cf259802d3d915e1e9062f88273de25e1c8db2e7cbb4bc77ef1faa65f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_96b0f79cf259802d3d915e1e9062f88273de25e1c8db2e7cbb4bc77ef1faa65f->enter($__internal_96b0f79cf259802d3d915e1e9062f88273de25e1c8db2e7cbb4bc77ef1faa65f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        echo "homepage";
        
        $__internal_96b0f79cf259802d3d915e1e9062f88273de25e1c8db2e7cbb4bc77ef1faa65f->leave($__internal_96b0f79cf259802d3d915e1e9062f88273de25e1c8db2e7cbb4bc77ef1faa65f_prof);

        
        $__internal_aecd3f773d26715b16f6c25f7f0bc107d30017efd92ca318b2cd4f519fcb1566->leave($__internal_aecd3f773d26715b16f6c25f7f0bc107d30017efd92ca318b2cd4f519fcb1566_prof);

    }

    // line 9
    public function block_header($context, array $blocks = array())
    {
        $__internal_5b730623fd32b5cecd519bdc64d2beeeb57c92c6c739c89be5aa943b6828f3cb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5b730623fd32b5cecd519bdc64d2beeeb57c92c6c739c89be5aa943b6828f3cb->enter($__internal_5b730623fd32b5cecd519bdc64d2beeeb57c92c6c739c89be5aa943b6828f3cb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header"));

        $__internal_8159286a04460c7914eb72b67c2a7fa79fe6edbf81600622459b56ffbd936b7e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8159286a04460c7914eb72b67c2a7fa79fe6edbf81600622459b56ffbd936b7e->enter($__internal_8159286a04460c7914eb72b67c2a7fa79fe6edbf81600622459b56ffbd936b7e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header"));

        
        $__internal_8159286a04460c7914eb72b67c2a7fa79fe6edbf81600622459b56ffbd936b7e->leave($__internal_8159286a04460c7914eb72b67c2a7fa79fe6edbf81600622459b56ffbd936b7e_prof);

        
        $__internal_5b730623fd32b5cecd519bdc64d2beeeb57c92c6c739c89be5aa943b6828f3cb->leave($__internal_5b730623fd32b5cecd519bdc64d2beeeb57c92c6c739c89be5aa943b6828f3cb_prof);

    }

    // line 12
    public function block_body($context, array $blocks = array())
    {
        $__internal_e55e1398f6962990a23b65c1e123917c8b07decc72cd74e64cdcb38f6e82d26d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e55e1398f6962990a23b65c1e123917c8b07decc72cd74e64cdcb38f6e82d26d->enter($__internal_e55e1398f6962990a23b65c1e123917c8b07decc72cd74e64cdcb38f6e82d26d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_895481e497490a12931d2dc25a755f11bf2c99523abd18141e557bdd8e18d447 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_895481e497490a12931d2dc25a755f11bf2c99523abd18141e557bdd8e18d447->enter($__internal_895481e497490a12931d2dc25a755f11bf2c99523abd18141e557bdd8e18d447_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 13
        echo "  <nav class=\"navbar navbar-expand-lg navbar-dark bg-dark\">
    <a class=\"navbar-brand\" href=\"";
        // line 14
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("homepage");
        echo "\">CR 14</a>
    <button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarSupportedContent\" aria-controls=\"navbarSupportedContent\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">
        <span class=\"navbar-toggler-icon\">";
        // line 16
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("menu.toggle_nav"), "html", null, true);
        echo "</span>
    </button>

    <div class=\"collapse navbar-collapse\" id=\"navbarSupportedContent\">
        <ul class=\"navbar-nav mr-auto\">
          ";
        // line 21
        $this->displayBlock('header_navigation_links', $context, $blocks);
        // line 35
        echo "
          ";
        // line 36
        if ($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array())) {
            // line 37
            echo "              <li class=\"nav-item\">
                  <a class=\"nav-link\" href=\"";
            // line 38
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("security_logout");
            echo "\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("menu.logout"), "html", null, true);
            echo "</a>
              </li>
          ";
        }
        // line 41
        echo "
          <li class=\"nav-item\">
              <a class=\"nav-link\" href=\"";
        // line 43
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("blog_search");
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("menu.search"), "html", null, true);
        echo "</a>
          </li>
        </ul>

      <div class=\"dropdown form-inline my-2 my-lg-0\">
        <button class=\"btn btn-light dropdown-toggle\" type=\"button\" id=\"dropdownMenuButton\" data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">
          ";
        // line 49
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("menu.choose_language"), "html", null, true);
        echo "
        </button>
        <div class=\"dropdown-menu\" aria-labelledby=\"dropdownMenuButton\">
          ";
        // line 52
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->env->getExtension('AppBundle\Twig\AppExtension')->getLocales());
        foreach ($context['_seq'] as $context["_key"] => $context["locale"]) {
            // line 53
            echo "            <p class=\"dropdown-item\" ";
            if (($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "locale", array()) == $this->getAttribute($context["locale"], "code", array()))) {
                echo "aria-checked=\"true\" class=\"active\"";
            } else {
                echo "aria-checked=\"false\"";
            }
            echo " role=\"menuitem\">
              <a href=\"";
            // line 54
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "get", array(0 => "_route", 1 => "blog_index"), "method"), twig_array_merge($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "get", array(0 => "_route_params", 1 => array()), "method"), array("_locale" => $this->getAttribute($context["locale"], "code", array())))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, $this->getAttribute($context["locale"], "name", array())), "html", null, true);
            echo "</a>
            </p>
          ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['locale'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 57
        echo "        </div>
      </div>
    </div>
  </nav>

    <div class=\"page-header\">
        <div id=\"carouselExampleIndicators\" class=\"carousel slide\" data-ride=\"carousel\">
            <div class=\"carousel-inner\">
            <div class=\"carousel-item active\">
                <img src=\"https://lh4.googleusercontent.com/uUg03ZwNThy1J70ajPOXk9XUMXWris4ziGYjiLOSmNqkHAEDeTPijtNm4zwG1uwzvlbQhYP7j4WXEkjNQBTPJTmyd0xuumwoYis3YG3kFq0qhmVbKudRywyHAkbTGer_D5KRSzQy\" alt=\"imges\">
                <div class=\"carousel-caption d-none d-md-block\">
                    <center>
                        <h1>";
        // line 69
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("title.homepage");
        echo "<h1>
                    </center>
                </div>
            </div>
            </div>
        </div>
    </div>


";
        
        $__internal_895481e497490a12931d2dc25a755f11bf2c99523abd18141e557bdd8e18d447->leave($__internal_895481e497490a12931d2dc25a755f11bf2c99523abd18141e557bdd8e18d447_prof);

        
        $__internal_e55e1398f6962990a23b65c1e123917c8b07decc72cd74e64cdcb38f6e82d26d->leave($__internal_e55e1398f6962990a23b65c1e123917c8b07decc72cd74e64cdcb38f6e82d26d_prof);

    }

    // line 21
    public function block_header_navigation_links($context, array $blocks = array())
    {
        $__internal_b7dc1b451c9eba8f2d23db58f196d52d6d542456a062dc260c8098d55dc89d1a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b7dc1b451c9eba8f2d23db58f196d52d6d542456a062dc260c8098d55dc89d1a->enter($__internal_b7dc1b451c9eba8f2d23db58f196d52d6d542456a062dc260c8098d55dc89d1a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header_navigation_links"));

        $__internal_049d4039b3d704a378d2e69aaabe5a6ffb0d2f16a5b16bee6a79745741a9941c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_049d4039b3d704a378d2e69aaabe5a6ffb0d2f16a5b16bee6a79745741a9941c->enter($__internal_049d4039b3d704a378d2e69aaabe5a6ffb0d2f16a5b16bee6a79745741a9941c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header_navigation_links"));

        // line 22
        echo "            <li class=\"nav-item active\">
              <a class=\"nav-link\" href=\"";
        // line 23
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("blog_index");
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("menu.homepage"), "html", null, true);
        echo " <span class=\"sr-only\">(current)</span></a>
            </li>
          ";
        // line 25
        if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("ROLE_ADMIN")) {
            // line 26
            echo "            <li class=\"nav-item\">
              <a class=\"nav-link\" href=\"";
            // line 27
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_post_index");
            echo "\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("menu.admin"), "html", null, true);
            echo "</a>
            </li>
          ";
        } else {
            // line 30
            echo "            <li class=\"nav-item\">
                <a class=\"nav-link\" href=\"";
            // line 31
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_post_index");
            echo "\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("action.browse_admin"), "html", null, true);
            echo "</a>
            </li>
          ";
        }
        // line 34
        echo "          ";
        
        $__internal_049d4039b3d704a378d2e69aaabe5a6ffb0d2f16a5b16bee6a79745741a9941c->leave($__internal_049d4039b3d704a378d2e69aaabe5a6ffb0d2f16a5b16bee6a79745741a9941c_prof);

        
        $__internal_b7dc1b451c9eba8f2d23db58f196d52d6d542456a062dc260c8098d55dc89d1a->leave($__internal_b7dc1b451c9eba8f2d23db58f196d52d6d542456a062dc260c8098d55dc89d1a_prof);

    }

    // line 80
    public function block_footer($context, array $blocks = array())
    {
        $__internal_4da94aea960c32081a489a36f263081bf8b629c1ca1ab32d847940e736a3184d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4da94aea960c32081a489a36f263081bf8b629c1ca1ab32d847940e736a3184d->enter($__internal_4da94aea960c32081a489a36f263081bf8b629c1ca1ab32d847940e736a3184d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        $__internal_376673c2171dbd39fdfc9755eedbd0ef46eef2207e4f4c030a7a26f5d04dda5a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_376673c2171dbd39fdfc9755eedbd0ef46eef2207e4f4c030a7a26f5d04dda5a->enter($__internal_376673c2171dbd39fdfc9755eedbd0ef46eef2207e4f4c030a7a26f5d04dda5a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        // line 81
        echo "    <section class=\"footer\">
        <div class=\"container-footer\">
            <div class=\"row\">
                <div class=\"p-1 col-md-4 col-sm-6\">
                    <h3>Hiyper Links</h3>
                    <ul>
                        <li><a href=\"";
        // line 87
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("blog_index");
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("menu.homepage"), "html", null, true);
        echo "</a></li>
                        <li><a href=\"";
        // line 88
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_post_index");
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("menu.admin"), "html", null, true);
        echo "</a></li>
                        <li><a href=\"";
        // line 89
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("blog_search");
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("menu.search"), "html", null, true);
        echo "</a></li>
                        <li><a href=\"";
        // line 90
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_post_index");
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("menu.post_list"), "html", null, true);
        echo "</a></li>
                        <li><a href=\"";
        // line 91
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("blog_index");
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("menu.back_to_blog"), "html", null, true);
        echo "</a></li>
                    </ul>
                </div>
                <div class=\"p-1 col-md-4 col-sm-6\">
                    <h3>Hiyper Links</h3>
                    <ul class=\"web\">
                        <li><i class=\"fab fa-3x fa-facebook\"></i></li>
                        <li><i class=\"fab fa-3x fa-instagram\"></i></li>
                        <li><i class=\"fab fa-3x fa-twitter-square\"></i></li>
                        <li><i class=\"fab fa-3x fa-youtube\"></i></li>
                        <li><i class=\"fab fa-3x fa-linkedin\"></i></li>
                    </ul>
                </div>
                <div class=\"p-1 col-md-4 col-sm-12\">
                    <h3>language</h3>
                    <button class=\"btn btn-light dropdown-toggle\" type=\"button\" id=\"dropdownMenuButton\" data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">
                        ";
        // line 107
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("menu.choose_language"), "html", null, true);
        echo "
                    </button>
                    <div class=\"dropdown-menu\" aria-labelledby=\"dropdownMenuButton\">
                        ";
        // line 110
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->env->getExtension('AppBundle\Twig\AppExtension')->getLocales());
        foreach ($context['_seq'] as $context["_key"] => $context["locale"]) {
            // line 111
            echo "                            <p class=\"dropdown-item\" ";
            if (($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "locale", array()) == $this->getAttribute($context["locale"], "code", array()))) {
                echo "aria-checked=\"true\" class=\"active\"";
            } else {
                echo "aria-checked=\"false\"";
            }
            echo " role=\"menuitem\">
                                <a href=\"";
            // line 112
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "get", array(0 => "_route", 1 => "blog_index"), "method"), twig_array_merge($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "get", array(0 => "_route_params", 1 => array()), "method"), array("_locale" => $this->getAttribute($context["locale"], "code", array())))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, $this->getAttribute($context["locale"], "name", array())), "html", null, true);
            echo "</a>
                            </p>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['locale'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 115
        echo "                    </div>
                </div>
            </div>
        </div>
    </section>
    <footer class=\"bg-dark text-center p-2\" style=\"color:#fff\">
        <div class=\"container\">
            <div id=\"footer-copyright\">
                <span>&copy; ";
        // line 123
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, "now", "Y"), "html", null, true);
        echo " - The Symfony Project</span>
                <span>";
        // line 124
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("mit_license"), "html", null, true);
        echo "</span>
            </div>
        </div>
    </footer>
";
        
        $__internal_376673c2171dbd39fdfc9755eedbd0ef46eef2207e4f4c030a7a26f5d04dda5a->leave($__internal_376673c2171dbd39fdfc9755eedbd0ef46eef2207e4f4c030a7a26f5d04dda5a_prof);

        
        $__internal_4da94aea960c32081a489a36f263081bf8b629c1ca1ab32d847940e736a3184d->leave($__internal_4da94aea960c32081a489a36f263081bf8b629c1ca1ab32d847940e736a3184d_prof);

    }

    public function getTemplateName()
    {
        return "default/homepage.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  360 => 124,  356 => 123,  346 => 115,  335 => 112,  326 => 111,  322 => 110,  316 => 107,  295 => 91,  289 => 90,  283 => 89,  277 => 88,  271 => 87,  263 => 81,  254 => 80,  244 => 34,  236 => 31,  233 => 30,  225 => 27,  222 => 26,  220 => 25,  213 => 23,  210 => 22,  201 => 21,  181 => 69,  167 => 57,  156 => 54,  147 => 53,  143 => 52,  137 => 49,  126 => 43,  122 => 41,  114 => 38,  111 => 37,  109 => 36,  106 => 35,  104 => 21,  96 => 16,  91 => 14,  88 => 13,  79 => 12,  62 => 9,  44 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body_id 'homepage' %}

{#
    the homepage is a special page which displays neither a header nor a footer.
    this is done with the 'trick' of defining empty Twig blocks without any content
#}
{% block header %}{% endblock %}


{% block body %}
  <nav class=\"navbar navbar-expand-lg navbar-dark bg-dark\">
    <a class=\"navbar-brand\" href=\"{{ path('homepage') }}\">CR 14</a>
    <button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarSupportedContent\" aria-controls=\"navbarSupportedContent\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">
        <span class=\"navbar-toggler-icon\">{{ 'menu.toggle_nav'|trans }}</span>
    </button>

    <div class=\"collapse navbar-collapse\" id=\"navbarSupportedContent\">
        <ul class=\"navbar-nav mr-auto\">
          {% block header_navigation_links %}
            <li class=\"nav-item active\">
              <a class=\"nav-link\" href=\"{{ path('blog_index') }}\">{{ 'menu.homepage'|trans }} <span class=\"sr-only\">(current)</span></a>
            </li>
          {% if is_granted('ROLE_ADMIN') %}
            <li class=\"nav-item\">
              <a class=\"nav-link\" href=\"{{ path('admin_post_index') }}\">{{ 'menu.admin'|trans }}</a>
            </li>
          {% else %}
            <li class=\"nav-item\">
                <a class=\"nav-link\" href=\"{{ path('admin_post_index') }}\">{{ 'action.browse_admin'|trans }}</a>
            </li>
          {% endif %}
          {% endblock %}

          {% if app.user %}
              <li class=\"nav-item\">
                  <a class=\"nav-link\" href=\"{{ path('security_logout') }}\">{{ 'menu.logout'|trans }}</a>
              </li>
          {% endif %}

          <li class=\"nav-item\">
              <a class=\"nav-link\" href=\"{{ path('blog_search') }}\">{{ 'menu.search'|trans }}</a>
          </li>
        </ul>

      <div class=\"dropdown form-inline my-2 my-lg-0\">
        <button class=\"btn btn-light dropdown-toggle\" type=\"button\" id=\"dropdownMenuButton\" data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">
          {{ 'menu.choose_language'|trans }}
        </button>
        <div class=\"dropdown-menu\" aria-labelledby=\"dropdownMenuButton\">
          {% for locale in locales() %}
            <p class=\"dropdown-item\" {% if app.request.locale == locale.code %}aria-checked=\"true\" class=\"active\"{% else %}aria-checked=\"false\"{% endif %} role=\"menuitem\">
              <a href=\"{{ path(app.request.get('_route', 'blog_index'), app.request.get('_route_params', [])|merge({_locale: locale.code})) }}\">{{ locale.name|capitalize }}</a>
            </p>
          {% endfor %}
        </div>
      </div>
    </div>
  </nav>

    <div class=\"page-header\">
        <div id=\"carouselExampleIndicators\" class=\"carousel slide\" data-ride=\"carousel\">
            <div class=\"carousel-inner\">
            <div class=\"carousel-item active\">
                <img src=\"https://lh4.googleusercontent.com/uUg03ZwNThy1J70ajPOXk9XUMXWris4ziGYjiLOSmNqkHAEDeTPijtNm4zwG1uwzvlbQhYP7j4WXEkjNQBTPJTmyd0xuumwoYis3YG3kFq0qhmVbKudRywyHAkbTGer_D5KRSzQy\" alt=\"imges\">
                <div class=\"carousel-caption d-none d-md-block\">
                    <center>
                        <h1>{{ 'title.homepage'|trans|raw }}<h1>
                    </center>
                </div>
            </div>
            </div>
        </div>
    </div>


{% endblock %}

{% block footer %}
    <section class=\"footer\">
        <div class=\"container-footer\">
            <div class=\"row\">
                <div class=\"p-1 col-md-4 col-sm-6\">
                    <h3>Hiyper Links</h3>
                    <ul>
                        <li><a href=\"{{ path('blog_index') }}\">{{ 'menu.homepage'|trans }}</a></li>
                        <li><a href=\"{{ path('admin_post_index') }}\">{{ 'menu.admin'|trans }}</a></li>
                        <li><a href=\"{{ path('blog_search') }}\">{{ 'menu.search'|trans }}</a></li>
                        <li><a href=\"{{ path('admin_post_index') }}\">{{ 'menu.post_list'|trans }}</a></li>
                        <li><a href=\"{{ path('blog_index') }}\">{{ 'menu.back_to_blog'|trans }}</a></li>
                    </ul>
                </div>
                <div class=\"p-1 col-md-4 col-sm-6\">
                    <h3>Hiyper Links</h3>
                    <ul class=\"web\">
                        <li><i class=\"fab fa-3x fa-facebook\"></i></li>
                        <li><i class=\"fab fa-3x fa-instagram\"></i></li>
                        <li><i class=\"fab fa-3x fa-twitter-square\"></i></li>
                        <li><i class=\"fab fa-3x fa-youtube\"></i></li>
                        <li><i class=\"fab fa-3x fa-linkedin\"></i></li>
                    </ul>
                </div>
                <div class=\"p-1 col-md-4 col-sm-12\">
                    <h3>language</h3>
                    <button class=\"btn btn-light dropdown-toggle\" type=\"button\" id=\"dropdownMenuButton\" data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">
                        {{ 'menu.choose_language'|trans }}
                    </button>
                    <div class=\"dropdown-menu\" aria-labelledby=\"dropdownMenuButton\">
                        {% for locale in locales() %}
                            <p class=\"dropdown-item\" {% if app.request.locale == locale.code %}aria-checked=\"true\" class=\"active\"{% else %}aria-checked=\"false\"{% endif %} role=\"menuitem\">
                                <a href=\"{{ path(app.request.get('_route', 'blog_index'), app.request.get('_route_params', [])|merge({_locale: locale.code})) }}\">{{ locale.name|capitalize }}</a>
                            </p>
                        {% endfor %}
                    </div>
                </div>
            </div>
        </div>
    </section>
    <footer class=\"bg-dark text-center p-2\" style=\"color:#fff\">
        <div class=\"container\">
            <div id=\"footer-copyright\">
                <span>&copy; {{ 'now'|date('Y') }} - The Symfony Project</span>
                <span>{{ 'mit_license'|trans }}</span>
            </div>
        </div>
    </footer>
{% endblock %}
", "default/homepage.html.twig", "C:\\xampp\\htdocs\\Moaz-Sabri-FSWD30-CodeReview14\\app\\Resources\\views\\default\\homepage.html.twig");
    }
}
