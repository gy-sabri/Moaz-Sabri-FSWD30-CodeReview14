<?php

/* @WebProfiler/Collector/exception.html.twig */
class __TwigTemplate_90e74a6725932b59e5175b5bb3711b3cc8ab55e61a00bd09142f0bddf63655ce extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/exception.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_de724aa561fd9e2b0820af4f671df41ac3a7a9b28ad5748581a69aec1edd8c9e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_de724aa561fd9e2b0820af4f671df41ac3a7a9b28ad5748581a69aec1edd8c9e->enter($__internal_de724aa561fd9e2b0820af4f671df41ac3a7a9b28ad5748581a69aec1edd8c9e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $__internal_5948fb32960d9aa619b615466829441b49df8d0f1284a5ed29363c652b0cf142 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5948fb32960d9aa619b615466829441b49df8d0f1284a5ed29363c652b0cf142->enter($__internal_5948fb32960d9aa619b615466829441b49df8d0f1284a5ed29363c652b0cf142_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_de724aa561fd9e2b0820af4f671df41ac3a7a9b28ad5748581a69aec1edd8c9e->leave($__internal_de724aa561fd9e2b0820af4f671df41ac3a7a9b28ad5748581a69aec1edd8c9e_prof);

        
        $__internal_5948fb32960d9aa619b615466829441b49df8d0f1284a5ed29363c652b0cf142->leave($__internal_5948fb32960d9aa619b615466829441b49df8d0f1284a5ed29363c652b0cf142_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_4357608f84fd3b053959bfaf697b63ce70b867bf851e7e55c25a7f96f8ca4e8d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4357608f84fd3b053959bfaf697b63ce70b867bf851e7e55c25a7f96f8ca4e8d->enter($__internal_4357608f84fd3b053959bfaf697b63ce70b867bf851e7e55c25a7f96f8ca4e8d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_1d725010a81cbeba830bca7420502364bd759c7a10e24eccba4e01a81e767477 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1d725010a81cbeba830bca7420502364bd759c7a10e24eccba4e01a81e767477->enter($__internal_1d725010a81cbeba830bca7420502364bd759c7a10e24eccba4e01a81e767477_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    ";
        if ($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 5
            echo "        <style>
            ";
            // line 6
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception_css", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
            echo "
        </style>
    ";
        }
        // line 9
        echo "    ";
        $this->displayParentBlock("head", $context, $blocks);
        echo "
";
        
        $__internal_1d725010a81cbeba830bca7420502364bd759c7a10e24eccba4e01a81e767477->leave($__internal_1d725010a81cbeba830bca7420502364bd759c7a10e24eccba4e01a81e767477_prof);

        
        $__internal_4357608f84fd3b053959bfaf697b63ce70b867bf851e7e55c25a7f96f8ca4e8d->leave($__internal_4357608f84fd3b053959bfaf697b63ce70b867bf851e7e55c25a7f96f8ca4e8d_prof);

    }

    // line 12
    public function block_menu($context, array $blocks = array())
    {
        $__internal_3f5df904b16d414b3750744a851c8ef92090b26fe1b819eb537b666fee59f463 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3f5df904b16d414b3750744a851c8ef92090b26fe1b819eb537b666fee59f463->enter($__internal_3f5df904b16d414b3750744a851c8ef92090b26fe1b819eb537b666fee59f463_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_e5e5176f3dd83dbe34a6d159d1326d647008a3214808c54d7f17b36ebbaf0dda = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e5e5176f3dd83dbe34a6d159d1326d647008a3214808c54d7f17b36ebbaf0dda->enter($__internal_e5e5176f3dd83dbe34a6d159d1326d647008a3214808c54d7f17b36ebbaf0dda_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 13
        echo "    <span class=\"label ";
        echo (($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) ? ("label-status-error") : ("disabled"));
        echo "\">
        <span class=\"icon\">";
        // line 14
        echo twig_include($this->env, $context, "@WebProfiler/Icon/exception.svg");
        echo "</span>
        <strong>Exception</strong>
        ";
        // line 16
        if ($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 17
            echo "            <span class=\"count\">
                <span>1</span>
            </span>
        ";
        }
        // line 21
        echo "    </span>
";
        
        $__internal_e5e5176f3dd83dbe34a6d159d1326d647008a3214808c54d7f17b36ebbaf0dda->leave($__internal_e5e5176f3dd83dbe34a6d159d1326d647008a3214808c54d7f17b36ebbaf0dda_prof);

        
        $__internal_3f5df904b16d414b3750744a851c8ef92090b26fe1b819eb537b666fee59f463->leave($__internal_3f5df904b16d414b3750744a851c8ef92090b26fe1b819eb537b666fee59f463_prof);

    }

    // line 24
    public function block_panel($context, array $blocks = array())
    {
        $__internal_9c1021d33928982e54afc9de0d5cd1215747034a1ce8e9120069615f353433d3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9c1021d33928982e54afc9de0d5cd1215747034a1ce8e9120069615f353433d3->enter($__internal_9c1021d33928982e54afc9de0d5cd1215747034a1ce8e9120069615f353433d3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_dcb3d42265a4c73d808e4fc30036fc859d89c80f99dd388e0a226262494eb1bb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_dcb3d42265a4c73d808e4fc30036fc859d89c80f99dd388e0a226262494eb1bb->enter($__internal_dcb3d42265a4c73d808e4fc30036fc859d89c80f99dd388e0a226262494eb1bb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 25
        echo "    <h2>Exceptions</h2>

    ";
        // line 27
        if ( !$this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 28
            echo "        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    ";
        } else {
            // line 32
            echo "        <div class=\"sf-reset\">
            ";
            // line 33
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
            echo "
        </div>
    ";
        }
        
        $__internal_dcb3d42265a4c73d808e4fc30036fc859d89c80f99dd388e0a226262494eb1bb->leave($__internal_dcb3d42265a4c73d808e4fc30036fc859d89c80f99dd388e0a226262494eb1bb_prof);

        
        $__internal_9c1021d33928982e54afc9de0d5cd1215747034a1ce8e9120069615f353433d3->leave($__internal_9c1021d33928982e54afc9de0d5cd1215747034a1ce8e9120069615f353433d3_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/exception.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 33,  135 => 32,  129 => 28,  127 => 27,  123 => 25,  114 => 24,  103 => 21,  97 => 17,  95 => 16,  90 => 14,  85 => 13,  76 => 12,  63 => 9,  57 => 6,  54 => 5,  51 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block head %}
    {% if collector.hasexception %}
        <style>
            {{ render(path('_profiler_exception_css', { token: token })) }}
        </style>
    {% endif %}
    {{ parent() }}
{% endblock %}

{% block menu %}
    <span class=\"label {{ collector.hasexception ? 'label-status-error' : 'disabled' }}\">
        <span class=\"icon\">{{ include('@WebProfiler/Icon/exception.svg') }}</span>
        <strong>Exception</strong>
        {% if collector.hasexception %}
            <span class=\"count\">
                <span>1</span>
            </span>
        {% endif %}
    </span>
{% endblock %}

{% block panel %}
    <h2>Exceptions</h2>

    {% if not collector.hasexception %}
        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    {% else %}
        <div class=\"sf-reset\">
            {{ render(path('_profiler_exception', { token: token })) }}
        </div>
    {% endif %}
{% endblock %}
", "@WebProfiler/Collector/exception.html.twig", "C:\\xampp\\htdocs\\symfony_demo\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\exception.html.twig");
    }
}
