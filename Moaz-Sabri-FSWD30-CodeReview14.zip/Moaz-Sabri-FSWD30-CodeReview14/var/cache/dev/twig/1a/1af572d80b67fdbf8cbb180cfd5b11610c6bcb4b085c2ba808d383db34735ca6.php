<?php

/* @WebProfiler/Profiler/header.html.twig */
class __TwigTemplate_e950724be6155f698f8ce47c3dd393a524609ec5f0d8164dcfcc59da8da4bde3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4c76c9d3f0ad204527e96cc5e8dc87762a82c523d3ff113752cbdcfc48f6ee81 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4c76c9d3f0ad204527e96cc5e8dc87762a82c523d3ff113752cbdcfc48f6ee81->enter($__internal_4c76c9d3f0ad204527e96cc5e8dc87762a82c523d3ff113752cbdcfc48f6ee81_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/header.html.twig"));

        $__internal_391c6e40e97d78cf2fd5b7d480fd3c17447a29e28e7551487bd1dbd688cb265a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_391c6e40e97d78cf2fd5b7d480fd3c17447a29e28e7551487bd1dbd688cb265a->enter($__internal_391c6e40e97d78cf2fd5b7d480fd3c17447a29e28e7551487bd1dbd688cb265a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/header.html.twig"));

        // line 1
        echo "<div id=\"header\">
    <div class=\"container\">
        <h1>";
        // line 3
        echo twig_include($this->env, $context, "@WebProfiler/Icon/symfony.svg");
        echo " Symfony <span>Profiler</span></h1>

        <div class=\"search\">
            <form method=\"get\" action=\"https://symfony.com/search\" target=\"_blank\">
                <div class=\"form-row\">
                    <input name=\"q\" id=\"search-id\" type=\"search\" placeholder=\"search on symfony.com\">
                    <button type=\"submit\" class=\"btn\">Search</button>
                </div>
           </form>
        </div>
    </div>
</div>
";
        
        $__internal_4c76c9d3f0ad204527e96cc5e8dc87762a82c523d3ff113752cbdcfc48f6ee81->leave($__internal_4c76c9d3f0ad204527e96cc5e8dc87762a82c523d3ff113752cbdcfc48f6ee81_prof);

        
        $__internal_391c6e40e97d78cf2fd5b7d480fd3c17447a29e28e7551487bd1dbd688cb265a->leave($__internal_391c6e40e97d78cf2fd5b7d480fd3c17447a29e28e7551487bd1dbd688cb265a_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Profiler/header.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  29 => 3,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div id=\"header\">
    <div class=\"container\">
        <h1>{{ include('@WebProfiler/Icon/symfony.svg') }} Symfony <span>Profiler</span></h1>

        <div class=\"search\">
            <form method=\"get\" action=\"https://symfony.com/search\" target=\"_blank\">
                <div class=\"form-row\">
                    <input name=\"q\" id=\"search-id\" type=\"search\" placeholder=\"search on symfony.com\">
                    <button type=\"submit\" class=\"btn\">Search</button>
                </div>
           </form>
        </div>
    </div>
</div>
", "@WebProfiler/Profiler/header.html.twig", "C:\\xampp\\htdocs\\symfony_demo\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Profiler\\header.html.twig");
    }
}
