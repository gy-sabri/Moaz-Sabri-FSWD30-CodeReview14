<?php

/* admin/layout.html.twig */
class __TwigTemplate_bc529a862402cfb725e95690923842d52b65f8cc8b94cd7819b3a2f59bc00955 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 8
        $this->parent = $this->loadTemplate("base.html.twig", "admin/layout.html.twig", 8);
        $this->blocks = array(
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
            'header_navigation_links' => array($this, 'block_header_navigation_links'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0610f74a170ec7bf7413527c9032c32dbea752c9c7e604a853bb7ce0591cf3b4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0610f74a170ec7bf7413527c9032c32dbea752c9c7e604a853bb7ce0591cf3b4->enter($__internal_0610f74a170ec7bf7413527c9032c32dbea752c9c7e604a853bb7ce0591cf3b4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "admin/layout.html.twig"));

        $__internal_455b1168a5973ffe0ddb6deb883d33515578196384b9d06a988d550ca13059c8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_455b1168a5973ffe0ddb6deb883d33515578196384b9d06a988d550ca13059c8->enter($__internal_455b1168a5973ffe0ddb6deb883d33515578196384b9d06a988d550ca13059c8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "admin/layout.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_0610f74a170ec7bf7413527c9032c32dbea752c9c7e604a853bb7ce0591cf3b4->leave($__internal_0610f74a170ec7bf7413527c9032c32dbea752c9c7e604a853bb7ce0591cf3b4_prof);

        
        $__internal_455b1168a5973ffe0ddb6deb883d33515578196384b9d06a988d550ca13059c8->leave($__internal_455b1168a5973ffe0ddb6deb883d33515578196384b9d06a988d550ca13059c8_prof);

    }

    // line 10
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_b0c5cdc334717c960a388463051238f96e04ee30602a60712d4416d2206d8a2d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b0c5cdc334717c960a388463051238f96e04ee30602a60712d4416d2206d8a2d->enter($__internal_b0c5cdc334717c960a388463051238f96e04ee30602a60712d4416d2206d8a2d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_8fb7c8ed654c2b132cf2018e4193dfefeb71e78ea6d6d78b26cc9fe719aeffdf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8fb7c8ed654c2b132cf2018e4193dfefeb71e78ea6d6d78b26cc9fe719aeffdf->enter($__internal_8fb7c8ed654c2b132cf2018e4193dfefeb71e78ea6d6d78b26cc9fe719aeffdf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 11
        echo "    ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
    <link rel=\"stylesheet\" href=\"";
        // line 12
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("build/css/admin.css"), "html", null, true);
        echo "\">
";
        
        $__internal_8fb7c8ed654c2b132cf2018e4193dfefeb71e78ea6d6d78b26cc9fe719aeffdf->leave($__internal_8fb7c8ed654c2b132cf2018e4193dfefeb71e78ea6d6d78b26cc9fe719aeffdf_prof);

        
        $__internal_b0c5cdc334717c960a388463051238f96e04ee30602a60712d4416d2206d8a2d->leave($__internal_b0c5cdc334717c960a388463051238f96e04ee30602a60712d4416d2206d8a2d_prof);

    }

    // line 15
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_1485c01ec76cd7120ebc95e05110c43de427c6653f8c81dfa868007e12da0a6f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1485c01ec76cd7120ebc95e05110c43de427c6653f8c81dfa868007e12da0a6f->enter($__internal_1485c01ec76cd7120ebc95e05110c43de427c6653f8c81dfa868007e12da0a6f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_639fc765f2cfa210f7ed85c3c08e3c1df9cc2ccf4fc1159991cfc916e23922d0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_639fc765f2cfa210f7ed85c3c08e3c1df9cc2ccf4fc1159991cfc916e23922d0->enter($__internal_639fc765f2cfa210f7ed85c3c08e3c1df9cc2ccf4fc1159991cfc916e23922d0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 16
        echo "    ";
        $this->displayParentBlock("javascripts", $context, $blocks);
        echo "
    <script src=\"";
        // line 17
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("build/js/admin.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_639fc765f2cfa210f7ed85c3c08e3c1df9cc2ccf4fc1159991cfc916e23922d0->leave($__internal_639fc765f2cfa210f7ed85c3c08e3c1df9cc2ccf4fc1159991cfc916e23922d0_prof);

        
        $__internal_1485c01ec76cd7120ebc95e05110c43de427c6653f8c81dfa868007e12da0a6f->leave($__internal_1485c01ec76cd7120ebc95e05110c43de427c6653f8c81dfa868007e12da0a6f_prof);

    }

    // line 20
    public function block_header_navigation_links($context, array $blocks = array())
    {
        $__internal_8717601b95f2bff3e5c782b584e6b39fd2ec6d2f7f741d56c2edbe087c38c88f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8717601b95f2bff3e5c782b584e6b39fd2ec6d2f7f741d56c2edbe087c38c88f->enter($__internal_8717601b95f2bff3e5c782b584e6b39fd2ec6d2f7f741d56c2edbe087c38c88f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header_navigation_links"));

        $__internal_4c0d35f0c881cc651440cf66dce2974dae61f2ca3be5ccf75798d8f0f6501acd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4c0d35f0c881cc651440cf66dce2974dae61f2ca3be5ccf75798d8f0f6501acd->enter($__internal_4c0d35f0c881cc651440cf66dce2974dae61f2ca3be5ccf75798d8f0f6501acd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header_navigation_links"));

        // line 21
        echo "    <li class=\"nav-item\">
        <a class=\"nav-link\" href=\"";
        // line 22
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_post_index");
        echo "\">
            ";
        // line 23
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("menu.post_list"), "html", null, true);
        echo "
        </a>
    </li>
    <li class=\"nav-item\">
        <a class=\"nav-link\" href=\"";
        // line 27
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("blog_index");
        echo "\">
            ";
        // line 28
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("menu.back_to_blog"), "html", null, true);
        echo "
        </a>
    </li>
";
        
        $__internal_4c0d35f0c881cc651440cf66dce2974dae61f2ca3be5ccf75798d8f0f6501acd->leave($__internal_4c0d35f0c881cc651440cf66dce2974dae61f2ca3be5ccf75798d8f0f6501acd_prof);

        
        $__internal_8717601b95f2bff3e5c782b584e6b39fd2ec6d2f7f741d56c2edbe087c38c88f->leave($__internal_8717601b95f2bff3e5c782b584e6b39fd2ec6d2f7f741d56c2edbe087c38c88f_prof);

    }

    public function getTemplateName()
    {
        return "admin/layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  121 => 28,  117 => 27,  110 => 23,  106 => 22,  103 => 21,  94 => 20,  82 => 17,  77 => 16,  68 => 15,  56 => 12,  51 => 11,  42 => 10,  11 => 8,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#
   This is the base template of the all backend pages. Since this layout is similar
   to the global layout, we inherit from it to just change the contents of some
   blocks. In practice, backend templates are using a three-level inheritance,
   showing how powerful, yet easy to use, is Twig's inheritance mechanism.
   See https://symfony.com/doc/current/book/templating.html#template-inheritance-and-layouts
#}
{% extends 'base.html.twig' %}

{% block stylesheets %}
    {{ parent() }}
    <link rel=\"stylesheet\" href=\"{{ asset('build/css/admin.css') }}\">
{% endblock %}

{% block javascripts %}
    {{ parent() }}
    <script src=\"{{ asset('build/js/admin.js') }}\"></script>
{% endblock %}

{% block header_navigation_links %}
    <li class=\"nav-item\">
        <a class=\"nav-link\" href=\"{{ path('admin_post_index') }}\">
            {{ 'menu.post_list'|trans }}
        </a>
    </li>
    <li class=\"nav-item\">
        <a class=\"nav-link\" href=\"{{ path('blog_index') }}\">
            {{ 'menu.back_to_blog'|trans }}
        </a>
    </li>
{% endblock %}
", "admin/layout.html.twig", "C:\\xampp\\htdocs\\symfony_demo\\app\\Resources\\views\\admin\\layout.html.twig");
    }
}
