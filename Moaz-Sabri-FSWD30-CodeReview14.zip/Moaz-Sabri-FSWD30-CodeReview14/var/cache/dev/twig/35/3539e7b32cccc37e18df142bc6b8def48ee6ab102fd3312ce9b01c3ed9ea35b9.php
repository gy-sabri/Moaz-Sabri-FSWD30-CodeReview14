<?php

/* blog/post_show.html.twig */
class __TwigTemplate_da73619f016f5faa3266129ab5af0ee99072dc5baadf566ddd49327199c4a21c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "blog/post_show.html.twig", 1);
        $this->blocks = array(
            'body_id' => array($this, 'block_body_id'),
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_47c753d67ff0ba3a0dba24a25c112e26710b2d64e8616c1e8d42764bc20813b6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_47c753d67ff0ba3a0dba24a25c112e26710b2d64e8616c1e8d42764bc20813b6->enter($__internal_47c753d67ff0ba3a0dba24a25c112e26710b2d64e8616c1e8d42764bc20813b6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "blog/post_show.html.twig"));

        $__internal_64cf439ff32fa9eeaab958b765f75ba0082e430709a82947f968a1938a04601f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_64cf439ff32fa9eeaab958b765f75ba0082e430709a82947f968a1938a04601f->enter($__internal_64cf439ff32fa9eeaab958b765f75ba0082e430709a82947f968a1938a04601f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "blog/post_show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_47c753d67ff0ba3a0dba24a25c112e26710b2d64e8616c1e8d42764bc20813b6->leave($__internal_47c753d67ff0ba3a0dba24a25c112e26710b2d64e8616c1e8d42764bc20813b6_prof);

        
        $__internal_64cf439ff32fa9eeaab958b765f75ba0082e430709a82947f968a1938a04601f->leave($__internal_64cf439ff32fa9eeaab958b765f75ba0082e430709a82947f968a1938a04601f_prof);

    }

    // line 3
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_bed5001382caa0b385bc68e08fa74337da033dfb800d69d88562ae128c227e62 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_bed5001382caa0b385bc68e08fa74337da033dfb800d69d88562ae128c227e62->enter($__internal_bed5001382caa0b385bc68e08fa74337da033dfb800d69d88562ae128c227e62_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_7095b6af47dece1073ea1ec3ba43df4a35b89fb98a269deb03df708bc5d26a24 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7095b6af47dece1073ea1ec3ba43df4a35b89fb98a269deb03df708bc5d26a24->enter($__internal_7095b6af47dece1073ea1ec3ba43df4a35b89fb98a269deb03df708bc5d26a24_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        echo "blog_post_show";
        
        $__internal_7095b6af47dece1073ea1ec3ba43df4a35b89fb98a269deb03df708bc5d26a24->leave($__internal_7095b6af47dece1073ea1ec3ba43df4a35b89fb98a269deb03df708bc5d26a24_prof);

        
        $__internal_bed5001382caa0b385bc68e08fa74337da033dfb800d69d88562ae128c227e62->leave($__internal_bed5001382caa0b385bc68e08fa74337da033dfb800d69d88562ae128c227e62_prof);

    }

    // line 5
    public function block_main($context, array $blocks = array())
    {
        $__internal_69fefd8175c08d217cb0b7e2abf500a541433a232fb96988d9a0e83710800356 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_69fefd8175c08d217cb0b7e2abf500a541433a232fb96988d9a0e83710800356->enter($__internal_69fefd8175c08d217cb0b7e2abf500a541433a232fb96988d9a0e83710800356_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_cfbea3adf25dba7af6dee9a792860f43f1efe7ee7f9a4d6276134ec4b6268a98 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cfbea3adf25dba7af6dee9a792860f43f1efe7ee7f9a4d6276134ec4b6268a98->enter($__internal_cfbea3adf25dba7af6dee9a792860f43f1efe7ee7f9a4d6276134ec4b6268a98_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 6
        echo "    <div class=\"container show-post\">
    
        <h1>";
        // line 8
        echo twig_escape_filter($this->env, $this->getAttribute(($context["post"] ?? $this->getContext($context, "post")), "title", array()), "html", null, true);
        echo "</h1>
        <div>
            <img src=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->getAttribute(($context["post"] ?? $this->getContext($context, "post")), "url", array()), "html", null, true);
        echo "\" class=\"w-100\">
        </div>
        <p class=\"post-metadata\">
            <span class=\"metadata\"><i class=\"fa fa-calendar\"></i> ";
        // line 13
        echo twig_escape_filter($this->env, twig_localized_date_filter($this->env, $this->getAttribute(($context["post"] ?? $this->getContext($context, "post")), "publishedAt", array()), "long", "medium", null, "UTC"), "html", null, true);
        echo "</span>
            <span class=\"metadata\"><i class=\"fa fa-user\"></i> ";
        // line 14
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["post"] ?? $this->getContext($context, "post")), "author", array()), "fullName", array()), "html", null, true);
        echo "</span>
        </p>

        ";
        // line 17
        echo $this->env->getExtension('AppBundle\Twig\AppExtension')->markdownToHtml($this->getAttribute(($context["post"] ?? $this->getContext($context, "post")), "content", array()));
        echo "

        ";
        // line 19
        echo twig_include($this->env, $context, "blog/_post_tags.html.twig");
        echo "

        <div id=\"post-add-comment\" class=\"well\">
            ";
        // line 28
        echo "            ";
        if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("IS_AUTHENTICATED_FULLY")) {
            // line 29
            echo "                ";
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("AppBundle:Blog:commentForm", array("id" => $this->getAttribute(($context["post"] ?? $this->getContext($context, "post")), "id", array()))));
            echo "
            ";
        } else {
            // line 31
            echo "                <p>
                    <a class=\"btn btn-success\" href=\"";
            // line 32
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("security_login");
            echo "\">
                        <i class=\"fa fa-sign-in\" aria-hidden=\"true\"></i> ";
            // line 33
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("action.sign_in"), "html", null, true);
            echo "
                    </a>
                    ";
            // line 35
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("post.to_publish_a_comment"), "html", null, true);
            echo "
                </p>
            ";
        }
        // line 38
        echo "        </div>

        <h3>
            <i class=\"fa fa-comments\" aria-hidden=\"true\"></i> ";
        // line 41
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->transchoice("post.num_comments", twig_length_filter($this->env, $this->getAttribute(($context["post"] ?? $this->getContext($context, "post")), "comments", array()))), "html", null, true);
        echo "
        </h3>

        ";
        // line 44
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute(($context["post"] ?? $this->getContext($context, "post")), "comments", array()));
        $context['_iterated'] = false;
        foreach ($context['_seq'] as $context["_key"] => $context["comment"]) {
            // line 45
            echo "            <div class=\"row post-comment\">
                <a name=\"comment_";
            // line 46
            echo twig_escape_filter($this->env, $this->getAttribute($context["comment"], "id", array()), "html", null, true);
            echo "\"></a>
                <i class=\"col-sm-3 mb-2\">
                    ";
            // line 48
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["comment"], "author", array()), "fullName", array()), "html", null, true);
            echo "<br> ";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("post.commented_on"), "html", null, true);
            echo "
                    ";
            // line 52
            echo "                    ";
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["comment"], "publishedAt", array()), "m/d/Y"), "html", null, true);
            echo "
                </i>
                <div class=\"col-sm-9\">
                    ";
            // line 55
            echo $this->env->getExtension('AppBundle\Twig\AppExtension')->markdownToHtml($this->getAttribute($context["comment"], "content", array()));
            echo "
                </div>
            </div>
             <hr>
        ";
            $context['_iterated'] = true;
        }
        if (!$context['_iterated']) {
            // line 60
            echo "            <div class=\"post-comment\">
                <p>";
            // line 61
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("post.no_comments"), "html", null, true);
            echo "</p>
            </div>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['comment'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 64
        echo "
        ";
        // line 65
        if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("edit", ($context["post"] ?? $this->getContext($context, "post")))) {
            // line 66
            echo "            <div class=\"section\">
                <a class=\"btn btn-lg btn-block btn-success\" href=\"";
            // line 67
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_post_edit", array("id" => $this->getAttribute(($context["post"] ?? $this->getContext($context, "post")), "id", array()))), "html", null, true);
            echo "\">
                    <i class=\"fa fa-edit\" aria-hidden=\"true\"></i> ";
            // line 68
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("action.edit_post"), "html", null, true);
            echo "
                </a>
            </div>
        ";
        }
        // line 72
        echo "    </div>
";
        
        $__internal_cfbea3adf25dba7af6dee9a792860f43f1efe7ee7f9a4d6276134ec4b6268a98->leave($__internal_cfbea3adf25dba7af6dee9a792860f43f1efe7ee7f9a4d6276134ec4b6268a98_prof);

        
        $__internal_69fefd8175c08d217cb0b7e2abf500a541433a232fb96988d9a0e83710800356->leave($__internal_69fefd8175c08d217cb0b7e2abf500a541433a232fb96988d9a0e83710800356_prof);

    }

    public function getTemplateName()
    {
        return "blog/post_show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  209 => 72,  202 => 68,  198 => 67,  195 => 66,  193 => 65,  190 => 64,  181 => 61,  178 => 60,  168 => 55,  161 => 52,  155 => 48,  150 => 46,  147 => 45,  142 => 44,  136 => 41,  131 => 38,  125 => 35,  120 => 33,  116 => 32,  113 => 31,  107 => 29,  104 => 28,  98 => 19,  93 => 17,  87 => 14,  83 => 13,  77 => 10,  72 => 8,  68 => 6,  59 => 5,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body_id 'blog_post_show' %}

{% block main %}
    <div class=\"container show-post\">
    
        <h1>{{ post.title }}</h1>
        <div>
            <img src=\"{{ post.url }}\" class=\"w-100\">
        </div>
        <p class=\"post-metadata\">
            <span class=\"metadata\"><i class=\"fa fa-calendar\"></i> {{ post.publishedAt|localizeddate('long', 'medium', null, 'UTC') }}</span>
            <span class=\"metadata\"><i class=\"fa fa-user\"></i> {{ post.author.fullName }}</span>
        </p>

        {{ post.content|md2html }}

        {{ include('blog/_post_tags.html.twig') }}

        <div id=\"post-add-comment\" class=\"well\">
            {# The 'IS_AUTHENTICATED_FULLY' role ensures that the user has entered
            his/her credentials (login + password) during this session. If he/she
            is automatically logged via the 'Remember Me' functionality, he/she won't
            be able to add a comment.
            See https://symfony.com/doc/current/cookbook/security/remember_me.html#forcing-the-user-to-re-authenticate-before-accessing-certain-resources
            #}
            {% if is_granted('IS_AUTHENTICATED_FULLY') %}
                {{ render(controller('AppBundle:Blog:commentForm', {'id': post.id})) }}
            {% else %}
                <p>
                    <a class=\"btn btn-success\" href=\"{{ path('security_login') }}\">
                        <i class=\"fa fa-sign-in\" aria-hidden=\"true\"></i> {{ 'action.sign_in'|trans }}
                    </a>
                    {{ 'post.to_publish_a_comment'|trans }}
                </p>
            {% endif %}
        </div>

        <h3>
            <i class=\"fa fa-comments\" aria-hidden=\"true\"></i> {{ 'post.num_comments'|transchoice(post.comments|length) }}
        </h3>

        {% for comment in post.comments %}
            <div class=\"row post-comment\">
                <a name=\"comment_{{ comment.id }}\"></a>
                <i class=\"col-sm-3 mb-2\">
                    {{ comment.author.fullName }}<br> {{ 'post.commented_on'|trans }}
                    {# it's not mandatory to set the timezone in localizeddate(). This is done to
                    avoid errors when the 'intl' PHP extension is not available and the application
                    is forced to use the limited \"intl polyfill\", which only supports UTC and GMT #}
                    {{ comment.publishedAt|date(\"m/d/Y\")}}
                </i>
                <div class=\"col-sm-9\">
                    {{ comment.content|md2html }}
                </div>
            </div>
             <hr>
        {% else %}
            <div class=\"post-comment\">
                <p>{{ 'post.no_comments'|trans }}</p>
            </div>
        {% endfor %}

        {% if is_granted('edit', post) %}
            <div class=\"section\">
                <a class=\"btn btn-lg btn-block btn-success\" href=\"{{ path('admin_post_edit', {id: post.id}) }}\">
                    <i class=\"fa fa-edit\" aria-hidden=\"true\"></i> {{ 'action.edit_post'|trans }}
                </a>
            </div>
        {% endif %}
    </div>
{% endblock %}
", "blog/post_show.html.twig", "C:\\xampp\\htdocs\\Moaz-Sabri-FSWD30-CodeReview14\\app\\Resources\\views\\blog\\post_show.html.twig");
    }
}
