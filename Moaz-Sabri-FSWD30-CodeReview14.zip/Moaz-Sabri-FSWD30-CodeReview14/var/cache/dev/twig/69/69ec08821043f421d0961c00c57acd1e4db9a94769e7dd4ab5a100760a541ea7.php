<?php

/* blog/index.html.twig */
class __TwigTemplate_143efbe6fd14073bc943b0b8f2db6cd291cb55a6751dd75b257a78ba8c646474 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "blog/index.html.twig", 1);
        $this->blocks = array(
            'body_id' => array($this, 'block_body_id'),
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d84c77ef3a46e482007186aa7f5c5e05224213e023e34d509350ffff3e62c5c9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d84c77ef3a46e482007186aa7f5c5e05224213e023e34d509350ffff3e62c5c9->enter($__internal_d84c77ef3a46e482007186aa7f5c5e05224213e023e34d509350ffff3e62c5c9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "blog/index.html.twig"));

        $__internal_0ef37d7df6933d5e3dd359011a6bfb47667cf7a15fbf8e0851ae7ff5e2e438a4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0ef37d7df6933d5e3dd359011a6bfb47667cf7a15fbf8e0851ae7ff5e2e438a4->enter($__internal_0ef37d7df6933d5e3dd359011a6bfb47667cf7a15fbf8e0851ae7ff5e2e438a4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "blog/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_d84c77ef3a46e482007186aa7f5c5e05224213e023e34d509350ffff3e62c5c9->leave($__internal_d84c77ef3a46e482007186aa7f5c5e05224213e023e34d509350ffff3e62c5c9_prof);

        
        $__internal_0ef37d7df6933d5e3dd359011a6bfb47667cf7a15fbf8e0851ae7ff5e2e438a4->leave($__internal_0ef37d7df6933d5e3dd359011a6bfb47667cf7a15fbf8e0851ae7ff5e2e438a4_prof);

    }

    // line 3
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_01efae609314254125339f72ed6c1e58556413a4bbbac659e773a8b98715dc9c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_01efae609314254125339f72ed6c1e58556413a4bbbac659e773a8b98715dc9c->enter($__internal_01efae609314254125339f72ed6c1e58556413a4bbbac659e773a8b98715dc9c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_e49dd0a0a4f2002141e33a8f782948c2499c1ce95b24a6ee691139c06dbc0cfe = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e49dd0a0a4f2002141e33a8f782948c2499c1ce95b24a6ee691139c06dbc0cfe->enter($__internal_e49dd0a0a4f2002141e33a8f782948c2499c1ce95b24a6ee691139c06dbc0cfe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        echo "blog_index";
        
        $__internal_e49dd0a0a4f2002141e33a8f782948c2499c1ce95b24a6ee691139c06dbc0cfe->leave($__internal_e49dd0a0a4f2002141e33a8f782948c2499c1ce95b24a6ee691139c06dbc0cfe_prof);

        
        $__internal_01efae609314254125339f72ed6c1e58556413a4bbbac659e773a8b98715dc9c->leave($__internal_01efae609314254125339f72ed6c1e58556413a4bbbac659e773a8b98715dc9c_prof);

    }

    // line 5
    public function block_main($context, array $blocks = array())
    {
        $__internal_4c6bd5480c0770efdcabbfc6419665e8fe0ce897145351887784a7b882010a80 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4c6bd5480c0770efdcabbfc6419665e8fe0ce897145351887784a7b882010a80->enter($__internal_4c6bd5480c0770efdcabbfc6419665e8fe0ce897145351887784a7b882010a80_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_f6e44818cfd0718b716209f678fc3d8d5c4c6f4a8756b18523eb37d01ba2c4d2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f6e44818cfd0718b716209f678fc3d8d5c4c6f4a8756b18523eb37d01ba2c4d2->enter($__internal_f6e44818cfd0718b716209f678fc3d8d5c4c6f4a8756b18523eb37d01ba2c4d2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 6
        echo "<div class=\"container all-event\">
        <div id=\"carouselExampleIndicators\" class=\"carousel slide\" data-ride=\"carousel\">
            <ol class=\"carousel-indicators\">
                    <li data-target=\"#carouselExampleIndicators\" data-slide-to=\"0\" class=\"active\"></li>
                ";
        // line 10
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["posts"] ?? $this->getContext($context, "posts")));
        foreach ($context['_seq'] as $context["_key"] => $context["post"]) {
            // line 11
            echo "                ";
            if ((($this->getAttribute($context["post"], "id", array()) > 0) && ($this->getAttribute($context["post"], "id", array()) < 5))) {
                // line 12
                echo "                    <li data-target=\"#carouselExampleIndicators\" data-slide-to=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($context["post"], "id", array()), "html", null, true);
                echo "\" ></li>
                ";
            }
            // line 14
            echo "                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['post'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 15
        echo "            </ol>
            <div class=\"carousel-inner\">
                ";
        // line 17
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["posts"] ?? $this->getContext($context, "posts")));
        foreach ($context['_seq'] as $context["_key"] => $context["post"]) {
            // line 18
            echo "                    <div class=\"carousel-item\">
                        <img src=\"";
            // line 19
            echo twig_escape_filter($this->env, $this->getAttribute($context["post"], "url", array()), "html", null, true);
            echo "\" alt=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["post"], "title", array()), "html", null, true);
            echo "\">
                        <div class=\"carousel-caption d-none d-md-block\">
                            <h5>";
            // line 21
            echo twig_escape_filter($this->env, $this->getAttribute($context["post"], "title", array()), "html", null, true);
            echo "</h5>
                            <p>";
            // line 22
            echo $this->env->getExtension('AppBundle\Twig\AppExtension')->markdownToHtml($this->getAttribute($context["post"], "summary", array()));
            echo "</p>
                        </div>
                    </div>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['post'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 26
        echo "                    <div class=\"carousel-item active\">
                        <img src=\"https://www.jetapp.ch/assets/jetapp/img/country/bg_ch.jpg\" alt=\"imges\">
                        <div class=\"carousel-caption d-none d-md-block\">
                            <h5>Guides & Touren in Wien</h5>
                            <p>Geführte Stadtrundgänge mit geprüften Fremdenführern, exklusive Kulinarik-Touren sowie Rundfahrten mit Bus, Rad, Schiff, Straßenbahn, Fahrrad und Segway zeigen die vielen unterschiedlichen Facetten Wiens.</p>
                        </div>
                    </div>
            </div>
            <a class=\"carousel-control-prev\" href=\"#carouselExampleIndicators\" role=\"button\" data-slide=\"prev\">
                <span class=\"carousel-control-prev-icon\" aria-hidden=\"true\"></span>
                <span class=\"sr-only\">Previous</span>
            </a>
            <a class=\"carousel-control-next\" href=\"#carouselExampleIndicators\" role=\"button\" data-slide=\"next\">
                <span class=\"carousel-control-next-icon\" aria-hidden=\"true\"></span>
                <span class=\"sr-only\">Next</span>
            </a>
        </div>

        
            <div class=\"row\">
                ";
        // line 46
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["posts"] ?? $this->getContext($context, "posts")));
        $context['_iterated'] = false;
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["post"]) {
            // line 47
            echo "                    
                        <div class=\"col-md-6\">
                            <div class=\"card m-2\">
                                <div class=\"card-body\">
                                    ";
            // line 52
            echo "                                        <h5><i class=\"far fa-clipboard\"> </i> ";
            echo twig_escape_filter($this->env, $this->getAttribute($context["post"], "category", array()), "html", null, true);
            echo "</h5>
                                    ";
            // line 54
            echo "                                    <div>
                                        <i class=\"fa fa-calendar\"></i> ";
            // line 55
            echo twig_escape_filter($this->env, twig_localized_date_filter($this->env, $this->getAttribute($context["post"], "publishedAt", array()), "long", "medium", null, "UTC"), "html", null, true);
            echo "
                                        <i class=\"fa fa-user\"></i> ";
            // line 56
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["post"], "author", array()), "fullName", array()), "html", null, true);
            echo "
                                    </div>
                                    <img src=\"";
            // line 58
            echo twig_escape_filter($this->env, $this->getAttribute($context["post"], "url", array()), "html", null, true);
            echo "\" class=\"w-100\">
                                    <a href=\"";
            // line 59
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("blog_post", array("slug" => $this->getAttribute($context["post"], "slug", array()))), "html", null, true);
            echo "\">
                                        <h2 class=\"card-title\">
                                            ";
            // line 61
            echo twig_escape_filter($this->env, $this->getAttribute($context["post"], "title", array()), "html", null, true);
            echo "
                                        </h2>
                                    </a>
                                    
                                    <p class=\"card-text\">";
            // line 65
            echo $this->env->getExtension('AppBundle\Twig\AppExtension')->markdownToHtml($this->getAttribute($context["post"], "summary", array()));
            echo "</p>
                                    <span class=\"tages\">";
            // line 66
            echo twig_include($this->env, $context, "blog/_post_tags.html.twig");
            echo "</span>
                                </div>
                            </div>
                        </div>
                ";
            $context['_iterated'] = true;
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        if (!$context['_iterated']) {
            // line 71
            echo "                    <div class=\"well\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("post.no_posts_found"), "html", null, true);
            echo "</div>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['post'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 73
        echo "            </div>
        </div>

    ";
        // line 76
        if ($this->getAttribute(($context["posts"] ?? $this->getContext($context, "posts")), "haveToPaginate", array())) {
            // line 77
            echo "        <center>
            ";
            // line 78
            echo $this->env->getExtension('WhiteOctober\PagerfantaBundle\Twig\PagerfantaExtension')->renderPagerfanta(($context["posts"] ?? $this->getContext($context, "posts")), "twitter_bootstrap3_translated", array("routeName" => "blog_index_paginated"));
            echo "
        </center>
    ";
        }
        
        $__internal_f6e44818cfd0718b716209f678fc3d8d5c4c6f4a8756b18523eb37d01ba2c4d2->leave($__internal_f6e44818cfd0718b716209f678fc3d8d5c4c6f4a8756b18523eb37d01ba2c4d2_prof);

        
        $__internal_4c6bd5480c0770efdcabbfc6419665e8fe0ce897145351887784a7b882010a80->leave($__internal_4c6bd5480c0770efdcabbfc6419665e8fe0ce897145351887784a7b882010a80_prof);

    }

    public function getTemplateName()
    {
        return "blog/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  245 => 78,  242 => 77,  240 => 76,  235 => 73,  226 => 71,  208 => 66,  204 => 65,  197 => 61,  192 => 59,  188 => 58,  183 => 56,  179 => 55,  176 => 54,  171 => 52,  165 => 47,  147 => 46,  125 => 26,  115 => 22,  111 => 21,  104 => 19,  101 => 18,  97 => 17,  93 => 15,  87 => 14,  81 => 12,  78 => 11,  74 => 10,  68 => 6,  59 => 5,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body_id 'blog_index' %}

{% block main %}
<div class=\"container all-event\">
        <div id=\"carouselExampleIndicators\" class=\"carousel slide\" data-ride=\"carousel\">
            <ol class=\"carousel-indicators\">
                    <li data-target=\"#carouselExampleIndicators\" data-slide-to=\"0\" class=\"active\"></li>
                {% for post in posts %}
                {% if post.id > 0 and post.id < 5 %}
                    <li data-target=\"#carouselExampleIndicators\" data-slide-to=\"{{ post.id }}\" ></li>
                {% endif %}
                {% endfor %}
            </ol>
            <div class=\"carousel-inner\">
                {% for post in posts %}
                    <div class=\"carousel-item\">
                        <img src=\"{{ post.url }}\" alt=\"{{ post.title }}\">
                        <div class=\"carousel-caption d-none d-md-block\">
                            <h5>{{ post.title }}</h5>
                            <p>{{ post.summary|md2html }}</p>
                        </div>
                    </div>
                {% endfor %}
                    <div class=\"carousel-item active\">
                        <img src=\"https://www.jetapp.ch/assets/jetapp/img/country/bg_ch.jpg\" alt=\"imges\">
                        <div class=\"carousel-caption d-none d-md-block\">
                            <h5>Guides & Touren in Wien</h5>
                            <p>Geführte Stadtrundgänge mit geprüften Fremdenführern, exklusive Kulinarik-Touren sowie Rundfahrten mit Bus, Rad, Schiff, Straßenbahn, Fahrrad und Segway zeigen die vielen unterschiedlichen Facetten Wiens.</p>
                        </div>
                    </div>
            </div>
            <a class=\"carousel-control-prev\" href=\"#carouselExampleIndicators\" role=\"button\" data-slide=\"prev\">
                <span class=\"carousel-control-prev-icon\" aria-hidden=\"true\"></span>
                <span class=\"sr-only\">Previous</span>
            </a>
            <a class=\"carousel-control-next\" href=\"#carouselExampleIndicators\" role=\"button\" data-slide=\"next\">
                <span class=\"carousel-control-next-icon\" aria-hidden=\"true\"></span>
                <span class=\"sr-only\">Next</span>
            </a>
        </div>

        
            <div class=\"row\">
                {% for post in posts %}
                    
                        <div class=\"col-md-6\">
                            <div class=\"card m-2\">
                                <div class=\"card-body\">
                                    {# <a href=\"{{ path('category_post', {slug: post.slug}) }}\"> #}
                                        <h5><i class=\"far fa-clipboard\"> </i> {{ post.category }}</h5>
                                    {# </a> #}
                                    <div>
                                        <i class=\"fa fa-calendar\"></i> {{ post.publishedAt|localizeddate('long', 'medium', null, 'UTC') }}
                                        <i class=\"fa fa-user\"></i> {{ post.author.fullName }}
                                    </div>
                                    <img src=\"{{ post.url }}\" class=\"w-100\">
                                    <a href=\"{{ path('blog_post', {slug: post.slug}) }}\">
                                        <h2 class=\"card-title\">
                                            {{ post.title }}
                                        </h2>
                                    </a>
                                    
                                    <p class=\"card-text\">{{ post.summary|md2html }}</p>
                                    <span class=\"tages\">{{ include('blog/_post_tags.html.twig') }}</span>
                                </div>
                            </div>
                        </div>
                {% else %}
                    <div class=\"well\">{{ 'post.no_posts_found'|trans }}</div>
                {% endfor %}
            </div>
        </div>

    {% if posts.haveToPaginate %}
        <center>
            {{ pagerfanta(posts, 'twitter_bootstrap3_translated', {routeName: 'blog_index_paginated'}) }}
        </center>
    {% endif %}
{% endblock %}



", "blog/index.html.twig", "C:\\xampp\\htdocs\\Moaz-Sabri-FSWD30-CodeReview14\\app\\Resources\\views\\blog\\index.html.twig");
    }
}
