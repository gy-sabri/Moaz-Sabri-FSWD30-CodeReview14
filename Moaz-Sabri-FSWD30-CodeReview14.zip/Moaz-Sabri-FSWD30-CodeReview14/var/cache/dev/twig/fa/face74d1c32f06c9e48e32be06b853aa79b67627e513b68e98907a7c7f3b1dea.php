<?php

/* form/layout.html.twig */
class __TwigTemplate_55790ad7228b119e07be7cfb2a5b6c8603c259438c16d5ec3aad6b22f43f6282 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("bootstrap_3_layout.html.twig", "form/layout.html.twig", 1);
        $this->blocks = array(
            'form_errors' => array($this, 'block_form_errors'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "bootstrap_3_layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_73e45920f6d6c4911a5f40ef43a1a2217f7be88fe9c6aaaf47a96df89d5b885f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_73e45920f6d6c4911a5f40ef43a1a2217f7be88fe9c6aaaf47a96df89d5b885f->enter($__internal_73e45920f6d6c4911a5f40ef43a1a2217f7be88fe9c6aaaf47a96df89d5b885f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "form/layout.html.twig"));

        $__internal_477730b6981772084fc687c3494aa1e029ee446821243cd37a756d8bfc201490 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_477730b6981772084fc687c3494aa1e029ee446821243cd37a756d8bfc201490->enter($__internal_477730b6981772084fc687c3494aa1e029ee446821243cd37a756d8bfc201490_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "form/layout.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_73e45920f6d6c4911a5f40ef43a1a2217f7be88fe9c6aaaf47a96df89d5b885f->leave($__internal_73e45920f6d6c4911a5f40ef43a1a2217f7be88fe9c6aaaf47a96df89d5b885f_prof);

        
        $__internal_477730b6981772084fc687c3494aa1e029ee446821243cd37a756d8bfc201490->leave($__internal_477730b6981772084fc687c3494aa1e029ee446821243cd37a756d8bfc201490_prof);

    }

    // line 5
    public function block_form_errors($context, array $blocks = array())
    {
        $__internal_822416bca0de9dcf55f109d81142451672578d61eed9f3c3770df2df90a8b3bd = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_822416bca0de9dcf55f109d81142451672578d61eed9f3c3770df2df90a8b3bd->enter($__internal_822416bca0de9dcf55f109d81142451672578d61eed9f3c3770df2df90a8b3bd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_errors"));

        $__internal_8d42b9befcc74fe0d114382707b3ba12d87d5a9ca6895dba09568a9e20f79033 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8d42b9befcc74fe0d114382707b3ba12d87d5a9ca6895dba09568a9e20f79033->enter($__internal_8d42b9befcc74fe0d114382707b3ba12d87d5a9ca6895dba09568a9e20f79033_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_errors"));

        // line 6
        if ((twig_length_filter($this->env, ($context["errors"] ?? $this->getContext($context, "errors"))) > 0)) {
            // line 7
            if ($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "parent", array())) {
                echo "<span class=\"help-block\">";
            } else {
                echo "<div class=\"alert alert-danger\">";
            }
            // line 8
            echo "        <ul class=\"list-unstyled\">";
            // line 9
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["errors"] ?? $this->getContext($context, "errors")));
            foreach ($context['_seq'] as $context["_key"] => $context["error"]) {
                // line 11
                echo "            <li><span class=\"fa fa-exclamation-triangle\"></span> ";
                echo twig_escape_filter($this->env, $this->getAttribute($context["error"], "message", array()), "html", null, true);
                echo "</li>";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['error'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 13
            echo "</ul>
        ";
            // line 14
            if ($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "parent", array())) {
                echo "</span>";
            } else {
                echo "</div>";
            }
        }
        
        $__internal_8d42b9befcc74fe0d114382707b3ba12d87d5a9ca6895dba09568a9e20f79033->leave($__internal_8d42b9befcc74fe0d114382707b3ba12d87d5a9ca6895dba09568a9e20f79033_prof);

        
        $__internal_822416bca0de9dcf55f109d81142451672578d61eed9f3c3770df2df90a8b3bd->leave($__internal_822416bca0de9dcf55f109d81142451672578d61eed9f3c3770df2df90a8b3bd_prof);

    }

    public function getTemplateName()
    {
        return "form/layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  74 => 14,  71 => 13,  63 => 11,  59 => 9,  57 => 8,  51 => 7,  49 => 6,  40 => 5,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'bootstrap_3_layout.html.twig' %}

{# Errors #}

{% block form_errors -%}
    {% if errors|length > 0 -%}
        {% if form.parent %}<span class=\"help-block\">{% else %}<div class=\"alert alert-danger\">{% endif %}
        <ul class=\"list-unstyled\">
        {%- for error in errors -%}
            {# use font-awesome icon library #}
            <li><span class=\"fa fa-exclamation-triangle\"></span> {{ error.message }}</li>
        {%- endfor -%}
        </ul>
        {% if form.parent %}</span>{% else %}</div>{% endif %}
    {%- endif %}
{%- endblock form_errors %}
", "form/layout.html.twig", "C:\\xampp\\htdocs\\symfony_demo\\app\\Resources\\views\\form\\layout.html.twig");
    }
}
