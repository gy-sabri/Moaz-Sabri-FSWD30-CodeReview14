<?php

/* blog/search.html.twig */
class __TwigTemplate_c5e29712124b5d18fdf1b22efece15dc06ec6391d1fe17eda0aea1848265add9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "blog/search.html.twig", 1);
        $this->blocks = array(
            'javascripts' => array($this, 'block_javascripts'),
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4c8de6ac42aecb31c60ca9d4f45119b634994fd2886b804366d247f59f078b97 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4c8de6ac42aecb31c60ca9d4f45119b634994fd2886b804366d247f59f078b97->enter($__internal_4c8de6ac42aecb31c60ca9d4f45119b634994fd2886b804366d247f59f078b97_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "blog/search.html.twig"));

        $__internal_6d4341afe905dca71332e98807681bb7a1b4d589e821aeebb302083d78badf50 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6d4341afe905dca71332e98807681bb7a1b4d589e821aeebb302083d78badf50->enter($__internal_6d4341afe905dca71332e98807681bb7a1b4d589e821aeebb302083d78badf50_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "blog/search.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_4c8de6ac42aecb31c60ca9d4f45119b634994fd2886b804366d247f59f078b97->leave($__internal_4c8de6ac42aecb31c60ca9d4f45119b634994fd2886b804366d247f59f078b97_prof);

        
        $__internal_6d4341afe905dca71332e98807681bb7a1b4d589e821aeebb302083d78badf50->leave($__internal_6d4341afe905dca71332e98807681bb7a1b4d589e821aeebb302083d78badf50_prof);

    }

    // line 3
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_41bfdcc46f7a0a7b0f6fe68ed46835d903c8237677423701976cbdd1f792102c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_41bfdcc46f7a0a7b0f6fe68ed46835d903c8237677423701976cbdd1f792102c->enter($__internal_41bfdcc46f7a0a7b0f6fe68ed46835d903c8237677423701976cbdd1f792102c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_3f9dfeec8bc2213c12ff20e49ba58f5c24bf794d1a6a1a559432d08c982de016 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3f9dfeec8bc2213c12ff20e49ba58f5c24bf794d1a6a1a559432d08c982de016->enter($__internal_3f9dfeec8bc2213c12ff20e49ba58f5c24bf794d1a6a1a559432d08c982de016_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 4
        echo "    ";
        $this->displayParentBlock("javascripts", $context, $blocks);
        echo "
    <script src=\"";
        // line 5
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("build/js/search.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_3f9dfeec8bc2213c12ff20e49ba58f5c24bf794d1a6a1a559432d08c982de016->leave($__internal_3f9dfeec8bc2213c12ff20e49ba58f5c24bf794d1a6a1a559432d08c982de016_prof);

        
        $__internal_41bfdcc46f7a0a7b0f6fe68ed46835d903c8237677423701976cbdd1f792102c->leave($__internal_41bfdcc46f7a0a7b0f6fe68ed46835d903c8237677423701976cbdd1f792102c_prof);

    }

    // line 8
    public function block_main($context, array $blocks = array())
    {
        $__internal_42874731bc68354fa40372b37476d900ef4a4500e23a3706517ddf846795a220 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_42874731bc68354fa40372b37476d900ef4a4500e23a3706517ddf846795a220->enter($__internal_42874731bc68354fa40372b37476d900ef4a4500e23a3706517ddf846795a220_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_5c2df2fb019ca8a24690800ab95db901e32b4193d4e1ed17f0807ce339cef5f1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5c2df2fb019ca8a24690800ab95db901e32b4193d4e1ed17f0807ce339cef5f1->enter($__internal_5c2df2fb019ca8a24690800ab95db901e32b4193d4e1ed17f0807ce339cef5f1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 9
        echo "    <div class=\"container\">
        <form action=\"";
        // line 10
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("blog_search");
        echo "\" method=\"get\">
            <div class=\"form-group\">
                <input name=\"q\" type=\"text\" class=\"form-control search-field\" placeholder=\"";
        // line 12
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("post.search_for"), "html", null, true);
        echo "\" autocomplete=\"off\" autofocus>
            </div>
        </form>

        <div id=\"results\">
        </div>
    </div>
";
        
        $__internal_5c2df2fb019ca8a24690800ab95db901e32b4193d4e1ed17f0807ce339cef5f1->leave($__internal_5c2df2fb019ca8a24690800ab95db901e32b4193d4e1ed17f0807ce339cef5f1_prof);

        
        $__internal_42874731bc68354fa40372b37476d900ef4a4500e23a3706517ddf846795a220->leave($__internal_42874731bc68354fa40372b37476d900ef4a4500e23a3706517ddf846795a220_prof);

    }

    public function getTemplateName()
    {
        return "blog/search.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  84 => 12,  79 => 10,  76 => 9,  67 => 8,  55 => 5,  50 => 4,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block javascripts %}
    {{ parent() }}
    <script src=\"{{ asset('build/js/search.js') }}\"></script>
{% endblock %}

{% block main %}
    <div class=\"container\">
        <form action=\"{{ path('blog_search') }}\" method=\"get\">
            <div class=\"form-group\">
                <input name=\"q\" type=\"text\" class=\"form-control search-field\" placeholder=\"{{ 'post.search_for'|trans }}\" autocomplete=\"off\" autofocus>
            </div>
        </form>

        <div id=\"results\">
        </div>
    </div>
{% endblock %}
", "blog/search.html.twig", "C:\\xampp\\htdocs\\symfony_demo\\app\\Resources\\views\\blog\\search.html.twig");
    }
}
