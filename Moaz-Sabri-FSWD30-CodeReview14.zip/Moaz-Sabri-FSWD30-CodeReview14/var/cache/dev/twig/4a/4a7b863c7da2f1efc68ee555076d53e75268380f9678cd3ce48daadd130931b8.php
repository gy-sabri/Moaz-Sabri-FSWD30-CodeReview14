<?php

/* @Twig/images/chevron-right.svg */
class __TwigTemplate_449483384ca2c2831faa0646c1ae9ee15d272854173c042347dfbf686f2c79e9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0f0e2004384beaeffcdcd00ad4850d788ad252f217705f260a8cf857ed08b231 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0f0e2004384beaeffcdcd00ad4850d788ad252f217705f260a8cf857ed08b231->enter($__internal_0f0e2004384beaeffcdcd00ad4850d788ad252f217705f260a8cf857ed08b231_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/images/chevron-right.svg"));

        $__internal_2e0f5e25b877dfab79d91a58f7fc19d50a0607f656d6b7b359b3907665a0a217 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2e0f5e25b877dfab79d91a58f7fc19d50a0607f656d6b7b359b3907665a0a217->enter($__internal_2e0f5e25b877dfab79d91a58f7fc19d50a0607f656d6b7b359b3907665a0a217_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/images/chevron-right.svg"));

        // line 1
        echo "<svg width=\"1792\" height=\"1792\" viewBox=\"0 0 1792 1792\" xmlns=\"http://www.w3.org/2000/svg\"><path fill=\"#FFF\" d=\"M1363 877l-742 742q-19 19-45 19t-45-19l-166-166q-19-19-19-45t19-45l531-531-531-531q-19-19-19-45t19-45l166-166q19-19 45-19t45 19l742 742q19 19 19 45t-19 45z\"/></svg>
";
        
        $__internal_0f0e2004384beaeffcdcd00ad4850d788ad252f217705f260a8cf857ed08b231->leave($__internal_0f0e2004384beaeffcdcd00ad4850d788ad252f217705f260a8cf857ed08b231_prof);

        
        $__internal_2e0f5e25b877dfab79d91a58f7fc19d50a0607f656d6b7b359b3907665a0a217->leave($__internal_2e0f5e25b877dfab79d91a58f7fc19d50a0607f656d6b7b359b3907665a0a217_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/images/chevron-right.svg";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<svg width=\"1792\" height=\"1792\" viewBox=\"0 0 1792 1792\" xmlns=\"http://www.w3.org/2000/svg\"><path fill=\"#FFF\" d=\"M1363 877l-742 742q-19 19-45 19t-45-19l-166-166q-19-19-19-45t19-45l531-531-531-531q-19-19-19-45t19-45l166-166q19-19 45-19t45 19l742 742q19 19 19 45t-19 45z\"/></svg>
", "@Twig/images/chevron-right.svg", "C:\\xampp\\htdocs\\symfony_demo\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\images\\chevron-right.svg");
    }
}
