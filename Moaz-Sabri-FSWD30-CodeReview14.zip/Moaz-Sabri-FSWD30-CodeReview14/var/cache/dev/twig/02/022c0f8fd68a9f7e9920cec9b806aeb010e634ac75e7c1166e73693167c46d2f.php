<?php

/* admin/blog/edit.html.twig */
class __TwigTemplate_9f1331297cf9e102bb2b4c6f8b69d996f0f66fe460cb6bee3d4f4c8f64a082b7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("admin/layout.html.twig", "admin/blog/edit.html.twig", 1);
        $this->blocks = array(
            'body_id' => array($this, 'block_body_id'),
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "admin/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5ee6d2ea5311aa2468aca24abccf70b5174ef5afbc1e74a78d268b4b9dca4d2c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5ee6d2ea5311aa2468aca24abccf70b5174ef5afbc1e74a78d268b4b9dca4d2c->enter($__internal_5ee6d2ea5311aa2468aca24abccf70b5174ef5afbc1e74a78d268b4b9dca4d2c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "admin/blog/edit.html.twig"));

        $__internal_dbbf3f0d123106bbc2004252ff034272dd4d111c836d56933169d63de222c450 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_dbbf3f0d123106bbc2004252ff034272dd4d111c836d56933169d63de222c450->enter($__internal_dbbf3f0d123106bbc2004252ff034272dd4d111c836d56933169d63de222c450_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "admin/blog/edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_5ee6d2ea5311aa2468aca24abccf70b5174ef5afbc1e74a78d268b4b9dca4d2c->leave($__internal_5ee6d2ea5311aa2468aca24abccf70b5174ef5afbc1e74a78d268b4b9dca4d2c_prof);

        
        $__internal_dbbf3f0d123106bbc2004252ff034272dd4d111c836d56933169d63de222c450->leave($__internal_dbbf3f0d123106bbc2004252ff034272dd4d111c836d56933169d63de222c450_prof);

    }

    // line 3
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_106fd34f7260f6d9de6150a3f704c115f0d4456bb7a74ed823fc92173b41159c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_106fd34f7260f6d9de6150a3f704c115f0d4456bb7a74ed823fc92173b41159c->enter($__internal_106fd34f7260f6d9de6150a3f704c115f0d4456bb7a74ed823fc92173b41159c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_bf011d3f53d626f18adb94d20bba639993579e0c134166f5c569d79c811b67bb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bf011d3f53d626f18adb94d20bba639993579e0c134166f5c569d79c811b67bb->enter($__internal_bf011d3f53d626f18adb94d20bba639993579e0c134166f5c569d79c811b67bb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        echo "admin_post_edit";
        
        $__internal_bf011d3f53d626f18adb94d20bba639993579e0c134166f5c569d79c811b67bb->leave($__internal_bf011d3f53d626f18adb94d20bba639993579e0c134166f5c569d79c811b67bb_prof);

        
        $__internal_106fd34f7260f6d9de6150a3f704c115f0d4456bb7a74ed823fc92173b41159c->leave($__internal_106fd34f7260f6d9de6150a3f704c115f0d4456bb7a74ed823fc92173b41159c_prof);

    }

    // line 5
    public function block_main($context, array $blocks = array())
    {
        $__internal_1c68402351947ece0068e2544768fe9a6bdf3ad6219d644b6f4320c211d4f375 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1c68402351947ece0068e2544768fe9a6bdf3ad6219d644b6f4320c211d4f375->enter($__internal_1c68402351947ece0068e2544768fe9a6bdf3ad6219d644b6f4320c211d4f375_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_14c8b78189bc817ab13a6fd39ff2c1d2f9daec6afa0332b1d5f550bdaf33569c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_14c8b78189bc817ab13a6fd39ff2c1d2f9daec6afa0332b1d5f550bdaf33569c->enter($__internal_14c8b78189bc817ab13a6fd39ff2c1d2f9daec6afa0332b1d5f550bdaf33569c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 6
        echo "    <div class=\"container edit-event\">
        <h1>";
        // line 7
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("title.edit_post", array("%id%" => $this->getAttribute(($context["post"] ?? $this->getContext($context, "post")), "id", array()))), "html", null, true);
        echo "</h1>
            <div>
            <img src=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->getAttribute(($context["post"] ?? $this->getContext($context, "post")), "url", array()), "html", null, true);
        echo "\" class=\"w-100\">
        </div>

        ";
        // line 12
        echo twig_include($this->env, $context, "admin/blog/_form.html.twig", array("form" =>         // line 13
($context["form"] ?? $this->getContext($context, "form")), "button_label" => $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("action.save"), "include_back_to_home_link" => true), false);
        // line 16
        echo "

        <hr>
        <div class=\"row\">
            <div class=\"section col-sm-6\">
                <a href=\"";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_post_show", array("id" => $this->getAttribute(($context["post"] ?? $this->getContext($context, "post")), "id", array()))), "html", null, true);
        echo "\" class=\"btn btn-lg btn-block btn-success\">
                    ";
        // line 22
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("action.show_post"), "html", null, true);
        echo "
                </a>
            </div>
            <div class=\"section col-sm-6\">
                ";
        // line 26
        echo twig_include($this->env, $context, "admin/blog/_delete_form.html.twig", array("post" => ($context["post"] ?? $this->getContext($context, "post"))), false);
        echo "
            </div>
        </div>
    </div>
";
        
        $__internal_14c8b78189bc817ab13a6fd39ff2c1d2f9daec6afa0332b1d5f550bdaf33569c->leave($__internal_14c8b78189bc817ab13a6fd39ff2c1d2f9daec6afa0332b1d5f550bdaf33569c_prof);

        
        $__internal_1c68402351947ece0068e2544768fe9a6bdf3ad6219d644b6f4320c211d4f375->leave($__internal_1c68402351947ece0068e2544768fe9a6bdf3ad6219d644b6f4320c211d4f375_prof);

    }

    public function getTemplateName()
    {
        return "admin/blog/edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  103 => 26,  96 => 22,  92 => 21,  85 => 16,  83 => 13,  82 => 12,  76 => 9,  71 => 7,  68 => 6,  59 => 5,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'admin/layout.html.twig' %}

{% block body_id 'admin_post_edit' %}

{% block main %}
    <div class=\"container edit-event\">
        <h1>{{ 'title.edit_post'|trans({'%id%': post.id}) }}</h1>
            <div>
            <img src=\"{{ post.url }}\" class=\"w-100\">
        </div>

        {{ include('admin/blog/_form.html.twig', {
            form: form,
            button_label: 'action.save'|trans,
            include_back_to_home_link: true,
        }, with_context = false) }}

        <hr>
        <div class=\"row\">
            <div class=\"section col-sm-6\">
                <a href=\"{{ path('admin_post_show', {id: post.id}) }}\" class=\"btn btn-lg btn-block btn-success\">
                    {{ 'action.show_post'|trans }}
                </a>
            </div>
            <div class=\"section col-sm-6\">
                {{ include('admin/blog/_delete_form.html.twig', {post: post}, with_context = false) }}
            </div>
        </div>
    </div>
{% endblock %}

    
", "admin/blog/edit.html.twig", "C:\\xampp\\htdocs\\Moaz-Sabri-FSWD30-CodeReview14\\app\\Resources\\views\\admin\\blog\\edit.html.twig");
    }
}
