<?php

/* admin/blog/index.html.twig */
class __TwigTemplate_9f0626246f7f927e11bc0113d7391965636e3d75a271b2d03d86f7c5813a6465 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("admin/layout.html.twig", "admin/blog/index.html.twig", 1);
        $this->blocks = array(
            'body_id' => array($this, 'block_body_id'),
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "admin/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b2b162454f344744fb2a294ba2aaca9ef3296b580c8f3201ee5d7502745ce446 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b2b162454f344744fb2a294ba2aaca9ef3296b580c8f3201ee5d7502745ce446->enter($__internal_b2b162454f344744fb2a294ba2aaca9ef3296b580c8f3201ee5d7502745ce446_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "admin/blog/index.html.twig"));

        $__internal_1388ec90ff3ceae8d09009deea649c1c8cb805770423d2fc15cc09a7ee129c08 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1388ec90ff3ceae8d09009deea649c1c8cb805770423d2fc15cc09a7ee129c08->enter($__internal_1388ec90ff3ceae8d09009deea649c1c8cb805770423d2fc15cc09a7ee129c08_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "admin/blog/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b2b162454f344744fb2a294ba2aaca9ef3296b580c8f3201ee5d7502745ce446->leave($__internal_b2b162454f344744fb2a294ba2aaca9ef3296b580c8f3201ee5d7502745ce446_prof);

        
        $__internal_1388ec90ff3ceae8d09009deea649c1c8cb805770423d2fc15cc09a7ee129c08->leave($__internal_1388ec90ff3ceae8d09009deea649c1c8cb805770423d2fc15cc09a7ee129c08_prof);

    }

    // line 2
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_0f67b5ad6b2aec58f5b6f1fe5da3d0e93c1fdfc1c6056cfbdf95e8f6d269611e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0f67b5ad6b2aec58f5b6f1fe5da3d0e93c1fdfc1c6056cfbdf95e8f6d269611e->enter($__internal_0f67b5ad6b2aec58f5b6f1fe5da3d0e93c1fdfc1c6056cfbdf95e8f6d269611e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_ebe6589b904af47515ee140036fa7ad3b5ee61041e0954dc014041adacdbbc63 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ebe6589b904af47515ee140036fa7ad3b5ee61041e0954dc014041adacdbbc63->enter($__internal_ebe6589b904af47515ee140036fa7ad3b5ee61041e0954dc014041adacdbbc63_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        echo "admin_post_index";
        
        $__internal_ebe6589b904af47515ee140036fa7ad3b5ee61041e0954dc014041adacdbbc63->leave($__internal_ebe6589b904af47515ee140036fa7ad3b5ee61041e0954dc014041adacdbbc63_prof);

        
        $__internal_0f67b5ad6b2aec58f5b6f1fe5da3d0e93c1fdfc1c6056cfbdf95e8f6d269611e->leave($__internal_0f67b5ad6b2aec58f5b6f1fe5da3d0e93c1fdfc1c6056cfbdf95e8f6d269611e_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_2393809c064c2d4f7cbb02ff9a5a9c6ebd8ff5273f5ad3912575ff5766d446f2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2393809c064c2d4f7cbb02ff9a5a9c6ebd8ff5273f5ad3912575ff5766d446f2->enter($__internal_2393809c064c2d4f7cbb02ff9a5a9c6ebd8ff5273f5ad3912575ff5766d446f2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_b73315b229851d0a90655175a2204545c82d09be0d2f503371859f6ee2939814 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b73315b229851d0a90655175a2204545c82d09be0d2f503371859f6ee2939814->enter($__internal_b73315b229851d0a90655175a2204545c82d09be0d2f503371859f6ee2939814_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "    <div class=\"container list-admin\">
        <h1>";
        // line 5
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("title.post_list"), "html", null, true);
        echo "</h1>
        <div class=\"section actions w-50 mb-3\">
            <a href=\"";
        // line 7
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_post_new");
        echo "\" class=\"btn btn-lg btn-block btn-success\">
                <i class=\"fa fa-plus\" aria-hidden=\"true\"></i> ";
        // line 8
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("action.create_post"), "html", null, true);
        echo "
            </a>
        </div>
        <table class=\"table table-striped table-middle-aligned\">
            <thead>
                <tr>
                    <th scope=\"col\">";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("label.title"), "html", null, true);
        echo "</th>
                    <th scope=\"col\"><i class=\"fa fa-calendar\" aria-hidden=\"true\"></i> ";
        // line 15
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("label.published_at"), "html", null, true);
        echo "</th>
                    <th scope=\"col\" class=\"text-center\"><i class=\"fa fa-cogs\" aria-hidden=\"true\"></i> ";
        // line 16
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("label.actions"), "html", null, true);
        echo "</th>
                </tr>
            </thead>
            <tbody>
            ";
        // line 20
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["posts"] ?? $this->getContext($context, "posts")));
        $context['_iterated'] = false;
        foreach ($context['_seq'] as $context["_key"] => $context["post"]) {
            // line 21
            echo "                <tr>
                    <td>
                        <a href=\"";
            // line 23
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_post_show", array("id" => $this->getAttribute($context["post"], "id", array()))), "html", null, true);
            echo "\" class=\"btn btn-sm btn-default\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["post"], "title", array()), "html", null, true);
            echo "
                        </a>
                    </td>
                    
                    ";
            // line 30
            echo "                    <td>";
            echo twig_escape_filter($this->env, twig_localized_date_filter($this->env, $this->getAttribute($context["post"], "publishedAt", array()), "medium", "short", null, "UTC"), "html", null, true);
            echo "</td>
                    <td class=\"text-right\">
                        <div class=\"item-actions\">
                        
                            <a href=\"";
            // line 34
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_post_edit", array("id" => $this->getAttribute($context["post"], "id", array()))), "html", null, true);
            echo "\" class=\"btn btn-sm btn-primary\">
                                <i class=\"fa fa-edit\" aria-hidden=\"true\"></i> ";
            // line 35
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("action.edit"), "html", null, true);
            echo "
                            </a>
                        </div>
                    </td>
                </tr>
            ";
            $context['_iterated'] = true;
        }
        if (!$context['_iterated']) {
            // line 41
            echo "                <tr>
                    <td colspan=\"4\" align=\"center\">";
            // line 42
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("post.no_posts_found"), "html", null, true);
            echo "</td>
            </tr>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['post'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 45
        echo "            </tbody>
        </table>

        <!-- // Table Users  -->
        <table class=\"table table-striped table-bordered table-hover\">
            <thead>
                <tr>
                    <th scope=\"col\">";
        // line 52
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("label.username"), "html", null, true);
        echo "</th>
                    <th scope=\"col\">";
        // line 53
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("label.password"), "html", null, true);
        echo "</th>
                    <th scope=\"col\">";
        // line 54
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("label.role"), "html", null, true);
        echo "</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>amdin</td>
                    <td>123456</td>
                    <td><code>ROLE_USER</code> (";
        // line 61
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("help.role_user"), "html", null, true);
        echo ")</td>
                </tr>
            </tbody>
        </table>
        <!-- ========================================== -->


        <div id=\"login-help\" class=\"col-sm-7 mt-5\">
            <h3>
            <i class=\"fa fa-long-arrow-left\" aria-hidden=\"true\"></i>
            ";
        // line 71
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("help.login_users"), "html", null, true);
        echo "
        </h3>

        <!-- // how you can create user -->
        <div id=\"login-users-help\" class=\"panel panel-default mt-5\">
            <div class=\"panel-body\">
                <p>
                    <span class=\"label label-success\">";
        // line 78
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("note"), "html", null, true);
        echo "</span>
                    ";
        // line 79
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("help.reload_fixtures"), "html", null, true);
        echo "<br/>

                    <code class=\"console\">\$ php bin/console doctrine:fixtures:load</code>
                </p>

                <p>
                    <span class=\"label label-success\">";
        // line 85
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("tip"), "html", null, true);
        echo "</span>
                    ";
        // line 86
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("help.add_user"), "html", null, true);
        echo "<br/>

                    <code class=\"console\">\$ php bin/console app:add-user</code>
                </p>
            </div>
        </div>
    </div>
";
        
        $__internal_b73315b229851d0a90655175a2204545c82d09be0d2f503371859f6ee2939814->leave($__internal_b73315b229851d0a90655175a2204545c82d09be0d2f503371859f6ee2939814_prof);

        
        $__internal_2393809c064c2d4f7cbb02ff9a5a9c6ebd8ff5273f5ad3912575ff5766d446f2->leave($__internal_2393809c064c2d4f7cbb02ff9a5a9c6ebd8ff5273f5ad3912575ff5766d446f2_prof);

    }

    public function getTemplateName()
    {
        return "admin/blog/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  224 => 86,  220 => 85,  211 => 79,  207 => 78,  197 => 71,  184 => 61,  174 => 54,  170 => 53,  166 => 52,  157 => 45,  148 => 42,  145 => 41,  134 => 35,  130 => 34,  122 => 30,  113 => 23,  109 => 21,  104 => 20,  97 => 16,  93 => 15,  89 => 14,  80 => 8,  76 => 7,  71 => 5,  68 => 4,  59 => 3,  41 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'admin/layout.html.twig' %}
{% block body_id 'admin_post_index' %}
{% block main %}
    <div class=\"container list-admin\">
        <h1>{{ 'title.post_list'|trans }}</h1>
        <div class=\"section actions w-50 mb-3\">
            <a href=\"{{ path('admin_post_new') }}\" class=\"btn btn-lg btn-block btn-success\">
                <i class=\"fa fa-plus\" aria-hidden=\"true\"></i> {{ 'action.create_post'|trans }}
            </a>
        </div>
        <table class=\"table table-striped table-middle-aligned\">
            <thead>
                <tr>
                    <th scope=\"col\">{{ 'label.title'|trans }}</th>
                    <th scope=\"col\"><i class=\"fa fa-calendar\" aria-hidden=\"true\"></i> {{ 'label.published_at'|trans }}</th>
                    <th scope=\"col\" class=\"text-center\"><i class=\"fa fa-cogs\" aria-hidden=\"true\"></i> {{ 'label.actions'|trans }}</th>
                </tr>
            </thead>
            <tbody>
            {% for post in posts %}
                <tr>
                    <td>
                        <a href=\"{{ path('admin_post_show', {id: post.id}) }}\" class=\"btn btn-sm btn-default\">{{ post.title }}
                        </a>
                    </td>
                    
                    {# it's not mandatory to set the timezone in localizeddate(). This is done to
                    avoid errors when the 'intl' PHP extension is not available and the application
                    is forced to use the limited \"intl polyfill\", which only supports UTC and GMT #}
                    <td>{{ post.publishedAt|localizeddate('medium', 'short', null, 'UTC') }}</td>
                    <td class=\"text-right\">
                        <div class=\"item-actions\">
                        
                            <a href=\"{{ path('admin_post_edit', {id: post.id}) }}\" class=\"btn btn-sm btn-primary\">
                                <i class=\"fa fa-edit\" aria-hidden=\"true\"></i> {{ 'action.edit'|trans }}
                            </a>
                        </div>
                    </td>
                </tr>
            {% else %}
                <tr>
                    <td colspan=\"4\" align=\"center\">{{ 'post.no_posts_found'|trans }}</td>
            </tr>
            {% endfor %}
            </tbody>
        </table>

        <!-- // Table Users  -->
        <table class=\"table table-striped table-bordered table-hover\">
            <thead>
                <tr>
                    <th scope=\"col\">{{ 'label.username'|trans }}</th>
                    <th scope=\"col\">{{ 'label.password'|trans }}</th>
                    <th scope=\"col\">{{ 'label.role'|trans }}</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>amdin</td>
                    <td>123456</td>
                    <td><code>ROLE_USER</code> ({{ 'help.role_user'|trans }})</td>
                </tr>
            </tbody>
        </table>
        <!-- ========================================== -->


        <div id=\"login-help\" class=\"col-sm-7 mt-5\">
            <h3>
            <i class=\"fa fa-long-arrow-left\" aria-hidden=\"true\"></i>
            {{ 'help.login_users'|trans }}
        </h3>

        <!-- // how you can create user -->
        <div id=\"login-users-help\" class=\"panel panel-default mt-5\">
            <div class=\"panel-body\">
                <p>
                    <span class=\"label label-success\">{{ 'note'|trans }}</span>
                    {{ 'help.reload_fixtures'|trans }}<br/>

                    <code class=\"console\">\$ php bin/console doctrine:fixtures:load</code>
                </p>

                <p>
                    <span class=\"label label-success\">{{ 'tip'|trans }}</span>
                    {{ 'help.add_user'|trans }}<br/>

                    <code class=\"console\">\$ php bin/console app:add-user</code>
                </p>
            </div>
        </div>
    </div>
{% endblock %}
", "admin/blog/index.html.twig", "C:\\xampp\\htdocs\\Moaz-Sabri-FSWD30-CodeReview14\\app\\Resources\\views\\admin\\blog\\index.html.twig");
    }
}
