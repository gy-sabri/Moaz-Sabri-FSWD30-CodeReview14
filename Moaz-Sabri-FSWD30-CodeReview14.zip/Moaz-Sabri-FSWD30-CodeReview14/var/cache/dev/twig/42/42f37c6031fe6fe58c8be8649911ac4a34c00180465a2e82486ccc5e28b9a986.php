<?php

/* base.html.twig */
class __TwigTemplate_c565ea085342dd829020a5d7b5d6b5c5f0e20d051b64dd571bfdec5b5a7f5349 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body_id' => array($this, 'block_body_id'),
            'header' => array($this, 'block_header'),
            'header_navigation_links' => array($this, 'block_header_navigation_links'),
            'body' => array($this, 'block_body'),
            'main' => array($this, 'block_main'),
            'footer' => array($this, 'block_footer'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_70be70565846257f867a809993b6357f18fc700c7e05c50bc285f3a6d024202e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_70be70565846257f867a809993b6357f18fc700c7e05c50bc285f3a6d024202e->enter($__internal_70be70565846257f867a809993b6357f18fc700c7e05c50bc285f3a6d024202e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_55526f46e50e61e121171c7be1c3979ce32126a0c5b2233313f56cafb6d0acc5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_55526f46e50e61e121171c7be1c3979ce32126a0c5b2233313f56cafb6d0acc5->enter($__internal_55526f46e50e61e121171c7be1c3979ce32126a0c5b2233313f56cafb6d0acc5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 6
        echo "<!DOCTYPE html>
<html lang=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "locale", array()), "html", null, true);
        echo "\">
    <head>
        <meta charset=\"UTF-8\" />
        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>
        <title>";
        // line 11
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        <link rel=\"alternate\" type=\"application/rss+xml\" title=\"";
        // line 12
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("rss.title"), "html", null, true);
        echo "\" href=\"";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("blog_rss");
        echo "\">
        
        <link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css\" integrity=\"sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm\" crossorigin=\"anonymous\">
        <link href=\"https://use.fontawesome.com/releases/v5.0.8/css/all.css\" rel=\"stylesheet\">
        ";
        // line 16
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 19
        echo "
        <link rel=\"icon\" type=\"image/x-icon\" href=\"https://www.tuwien.ac.at/fileadmin/t/tuwien/downloads/cd/CD_NEU_2009/TU_Logos_2009/TU-Signet.png\" />
    </head>

    <body id=\"";
        // line 23
        $this->displayBlock('body_id', $context, $blocks);
        echo "\" style=\"background-color: #eee\">

        ";
        // line 25
        $this->displayBlock('header', $context, $blocks);
        // line 72
        echo "
        <div class=\"body-container\">
            ";
        // line 74
        $this->displayBlock('body', $context, $blocks);
        // line 80
        echo "        </div>

        ";
        // line 82
        $this->displayBlock('footer', $context, $blocks);
        // line 131
        echo "
        <script src=\"https://code.jquery.com/jquery-3.2.1.slim.min.js\" integrity=\"sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN\" crossorigin=\"anonymous\"></script>
        <script src=\"https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js\" integrity=\"sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q\" crossorigin=\"anonymous\"></script>
        <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js\" integrity=\"sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl\" crossorigin=\"anonymous\"></script>
        ";
        // line 135
        $this->displayBlock('javascripts', $context, $blocks);
        // line 140
        echo "
        ";
        // line 144
        echo "        <!-- Page rendered on ";
        echo twig_escape_filter($this->env, twig_localized_date_filter($this->env, "now", "long", "long", null, "UTC"), "html", null, true);
        echo " -->
    </body>
</html>
";
        
        $__internal_70be70565846257f867a809993b6357f18fc700c7e05c50bc285f3a6d024202e->leave($__internal_70be70565846257f867a809993b6357f18fc700c7e05c50bc285f3a6d024202e_prof);

        
        $__internal_55526f46e50e61e121171c7be1c3979ce32126a0c5b2233313f56cafb6d0acc5->leave($__internal_55526f46e50e61e121171c7be1c3979ce32126a0c5b2233313f56cafb6d0acc5_prof);

    }

    // line 11
    public function block_title($context, array $blocks = array())
    {
        $__internal_28051cba503ba20dbe0083bcbb211a4d9bb6db0875349cb6994ec691eacaf95e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_28051cba503ba20dbe0083bcbb211a4d9bb6db0875349cb6994ec691eacaf95e->enter($__internal_28051cba503ba20dbe0083bcbb211a4d9bb6db0875349cb6994ec691eacaf95e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_7794ed6de34b5a8cfb05f8f99a4b27a6b333fe84652c12e19bc885c99391e94b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7794ed6de34b5a8cfb05f8f99a4b27a6b333fe84652c12e19bc885c99391e94b->enter($__internal_7794ed6de34b5a8cfb05f8f99a4b27a6b333fe84652c12e19bc885c99391e94b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Symfony Demo application";
        
        $__internal_7794ed6de34b5a8cfb05f8f99a4b27a6b333fe84652c12e19bc885c99391e94b->leave($__internal_7794ed6de34b5a8cfb05f8f99a4b27a6b333fe84652c12e19bc885c99391e94b_prof);

        
        $__internal_28051cba503ba20dbe0083bcbb211a4d9bb6db0875349cb6994ec691eacaf95e->leave($__internal_28051cba503ba20dbe0083bcbb211a4d9bb6db0875349cb6994ec691eacaf95e_prof);

    }

    // line 16
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_540cb540845c06ef3675038c29d29a8ebfe3aea92235adfd66c35947a4ad7033 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_540cb540845c06ef3675038c29d29a8ebfe3aea92235adfd66c35947a4ad7033->enter($__internal_540cb540845c06ef3675038c29d29a8ebfe3aea92235adfd66c35947a4ad7033_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_d326950f60b1f3ae39ed4af1d7c584d55b8fa978f3a33f6def8948020bc6e44e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d326950f60b1f3ae39ed4af1d7c584d55b8fa978f3a33f6def8948020bc6e44e->enter($__internal_d326950f60b1f3ae39ed4af1d7c584d55b8fa978f3a33f6def8948020bc6e44e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 17
        echo "            <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("build/css/app.css"), "html", null, true);
        echo "\">
        ";
        
        $__internal_d326950f60b1f3ae39ed4af1d7c584d55b8fa978f3a33f6def8948020bc6e44e->leave($__internal_d326950f60b1f3ae39ed4af1d7c584d55b8fa978f3a33f6def8948020bc6e44e_prof);

        
        $__internal_540cb540845c06ef3675038c29d29a8ebfe3aea92235adfd66c35947a4ad7033->leave($__internal_540cb540845c06ef3675038c29d29a8ebfe3aea92235adfd66c35947a4ad7033_prof);

    }

    // line 23
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_8c8c4726a18149377658e726513cd690ca618417270cd095d4f49f42ab5fd132 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8c8c4726a18149377658e726513cd690ca618417270cd095d4f49f42ab5fd132->enter($__internal_8c8c4726a18149377658e726513cd690ca618417270cd095d4f49f42ab5fd132_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_84e0fc16ab0864b3c71a9d2cf8842116008bd8a66667cae1a745b4ad72e46a20 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_84e0fc16ab0864b3c71a9d2cf8842116008bd8a66667cae1a745b4ad72e46a20->enter($__internal_84e0fc16ab0864b3c71a9d2cf8842116008bd8a66667cae1a745b4ad72e46a20_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        
        $__internal_84e0fc16ab0864b3c71a9d2cf8842116008bd8a66667cae1a745b4ad72e46a20->leave($__internal_84e0fc16ab0864b3c71a9d2cf8842116008bd8a66667cae1a745b4ad72e46a20_prof);

        
        $__internal_8c8c4726a18149377658e726513cd690ca618417270cd095d4f49f42ab5fd132->leave($__internal_8c8c4726a18149377658e726513cd690ca618417270cd095d4f49f42ab5fd132_prof);

    }

    // line 25
    public function block_header($context, array $blocks = array())
    {
        $__internal_776f6158829c6ccb056e2d0831a2091b88e6ae2712fe77c3b629907675bce0da = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_776f6158829c6ccb056e2d0831a2091b88e6ae2712fe77c3b629907675bce0da->enter($__internal_776f6158829c6ccb056e2d0831a2091b88e6ae2712fe77c3b629907675bce0da_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header"));

        $__internal_9b0de46db17f8d9633fb62cc779e382d9e380ee3940943d0411f28352db21108 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9b0de46db17f8d9633fb62cc779e382d9e380ee3940943d0411f28352db21108->enter($__internal_9b0de46db17f8d9633fb62cc779e382d9e380ee3940943d0411f28352db21108_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header"));

        // line 26
        echo "            <nav class=\"navbar navbar-expand-lg navbar-dark bg-dark\">
                <a class=\"navbar-brand\" href=\"";
        // line 27
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("homepage");
        echo "\">CR 14</a>
                <button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarSupportedContent\" aria-controls=\"navbarSupportedContent\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">
                    <span class=\"navbar-toggler-icon\"></span>
                </button>

                <div class=\"collapse navbar-collapse\" id=\"navbarSupportedContent\">
                    <ul class=\"navbar-nav mr-auto\">
                        ";
        // line 34
        $this->displayBlock('header_navigation_links', $context, $blocks);
        // line 44
        echo "
                        ";
        // line 45
        if ($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array())) {
            // line 46
            echo "                            <li class=\"nav-item\">
                                <a class=\"nav-link\" href=\"";
            // line 47
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("security_logout");
            echo "\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("menu.logout"), "html", null, true);
            echo "</a>
                            </li>
                        ";
        }
        // line 50
        echo "
                        <li class=\"nav-item\">
                            <a class=\"nav-link\" href=\"";
        // line 52
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("blog_search");
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("menu.search"), "html", null, true);
        echo "</a>
                        </li>
                    </ul>

                    <div class=\"dropdown form-inline my-2 my-lg-0\">
                        <button class=\"btn btn-light dropdown-toggle\" type=\"button\" id=\"dropdownMenuButton\" data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">
                            ";
        // line 58
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("menu.choose_language"), "html", null, true);
        echo "
                        </button>
                        <div class=\"dropdown-menu\" aria-labelledby=\"dropdownMenuButton\">
                            ";
        // line 61
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->env->getExtension('AppBundle\Twig\AppExtension')->getLocales());
        foreach ($context['_seq'] as $context["_key"] => $context["locale"]) {
            // line 62
            echo "                                <p class=\"dropdown-item\" ";
            if (($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "locale", array()) == $this->getAttribute($context["locale"], "code", array()))) {
                echo "aria-checked=\"true\" class=\"active\"";
            } else {
                echo "aria-checked=\"false\"";
            }
            echo " role=\"menuitem\">
                                    <a href=\"";
            // line 63
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "get", array(0 => "_route", 1 => "blog_index"), "method"), twig_array_merge($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "get", array(0 => "_route_params", 1 => array()), "method"), array("_locale" => $this->getAttribute($context["locale"], "code", array())))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, $this->getAttribute($context["locale"], "name", array())), "html", null, true);
            echo "</a>
                                </p>
                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['locale'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 66
        echo "                        </div>
                    </div>

                </div>
            </nav>
        ";
        
        $__internal_9b0de46db17f8d9633fb62cc779e382d9e380ee3940943d0411f28352db21108->leave($__internal_9b0de46db17f8d9633fb62cc779e382d9e380ee3940943d0411f28352db21108_prof);

        
        $__internal_776f6158829c6ccb056e2d0831a2091b88e6ae2712fe77c3b629907675bce0da->leave($__internal_776f6158829c6ccb056e2d0831a2091b88e6ae2712fe77c3b629907675bce0da_prof);

    }

    // line 34
    public function block_header_navigation_links($context, array $blocks = array())
    {
        $__internal_3816381df2b4ab4c8c76801c52ac126267cd488fcf506e3feda8968532507a37 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3816381df2b4ab4c8c76801c52ac126267cd488fcf506e3feda8968532507a37->enter($__internal_3816381df2b4ab4c8c76801c52ac126267cd488fcf506e3feda8968532507a37_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header_navigation_links"));

        $__internal_b547cfe99dfa136a814d1da468a78f058fc8ab385bac81d963e8b9c3fecdb81f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b547cfe99dfa136a814d1da468a78f058fc8ab385bac81d963e8b9c3fecdb81f->enter($__internal_b547cfe99dfa136a814d1da468a78f058fc8ab385bac81d963e8b9c3fecdb81f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header_navigation_links"));

        // line 35
        echo "                            <li class=\"nav-item active\">
                                <a class=\"nav-link\" href=\"";
        // line 36
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("blog_index");
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("menu.homepage"), "html", null, true);
        echo " <span class=\"sr-only\">(current)</span></a>
                            </li>
                        ";
        // line 38
        if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("ROLE_ADMIN")) {
            // line 39
            echo "                            <li class=\"nav-item\">
                                <a class=\"nav-link\" href=\"";
            // line 40
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_post_index");
            echo "\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("menu.admin"), "html", null, true);
            echo "</a>
                            </li>
                        ";
        }
        // line 43
        echo "                        ";
        
        $__internal_b547cfe99dfa136a814d1da468a78f058fc8ab385bac81d963e8b9c3fecdb81f->leave($__internal_b547cfe99dfa136a814d1da468a78f058fc8ab385bac81d963e8b9c3fecdb81f_prof);

        
        $__internal_3816381df2b4ab4c8c76801c52ac126267cd488fcf506e3feda8968532507a37->leave($__internal_3816381df2b4ab4c8c76801c52ac126267cd488fcf506e3feda8968532507a37_prof);

    }

    // line 74
    public function block_body($context, array $blocks = array())
    {
        $__internal_5da7811f82cdf9e029c6b522b475057c3cf7fb72d90cc01d5e1613bcb31d6519 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5da7811f82cdf9e029c6b522b475057c3cf7fb72d90cc01d5e1613bcb31d6519->enter($__internal_5da7811f82cdf9e029c6b522b475057c3cf7fb72d90cc01d5e1613bcb31d6519_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_b6e305f756a466b8b9dec6bdb7beb4113a36c9dda00c7a0d75c0d535a8ee0f86 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b6e305f756a466b8b9dec6bdb7beb4113a36c9dda00c7a0d75c0d535a8ee0f86->enter($__internal_b6e305f756a466b8b9dec6bdb7beb4113a36c9dda00c7a0d75c0d535a8ee0f86_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 75
        echo "            ";
        $this->displayBlock('main', $context, $blocks);
        // line 76
        echo "                <div class=\"container\">
                    ";
        // line 77
        echo twig_include($this->env, $context, "default/_flash_messages.html.twig");
        echo "
                </div>
            ";
        
        $__internal_b6e305f756a466b8b9dec6bdb7beb4113a36c9dda00c7a0d75c0d535a8ee0f86->leave($__internal_b6e305f756a466b8b9dec6bdb7beb4113a36c9dda00c7a0d75c0d535a8ee0f86_prof);

        
        $__internal_5da7811f82cdf9e029c6b522b475057c3cf7fb72d90cc01d5e1613bcb31d6519->leave($__internal_5da7811f82cdf9e029c6b522b475057c3cf7fb72d90cc01d5e1613bcb31d6519_prof);

    }

    // line 75
    public function block_main($context, array $blocks = array())
    {
        $__internal_f27a1abb1c5d25646dd50171a97d85c7c360d313960affe6f67f5bda4f7cbbdd = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f27a1abb1c5d25646dd50171a97d85c7c360d313960affe6f67f5bda4f7cbbdd->enter($__internal_f27a1abb1c5d25646dd50171a97d85c7c360d313960affe6f67f5bda4f7cbbdd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_6cfc77267a81bbebf3ab7e5cac65c668eec30484c78ae01f00dc541b7de26fe8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6cfc77267a81bbebf3ab7e5cac65c668eec30484c78ae01f00dc541b7de26fe8->enter($__internal_6cfc77267a81bbebf3ab7e5cac65c668eec30484c78ae01f00dc541b7de26fe8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        
        $__internal_6cfc77267a81bbebf3ab7e5cac65c668eec30484c78ae01f00dc541b7de26fe8->leave($__internal_6cfc77267a81bbebf3ab7e5cac65c668eec30484c78ae01f00dc541b7de26fe8_prof);

        
        $__internal_f27a1abb1c5d25646dd50171a97d85c7c360d313960affe6f67f5bda4f7cbbdd->leave($__internal_f27a1abb1c5d25646dd50171a97d85c7c360d313960affe6f67f5bda4f7cbbdd_prof);

    }

    // line 82
    public function block_footer($context, array $blocks = array())
    {
        $__internal_624fffd4e87157fd2531d2490eaf1ad73281780d0beb5de89d1b59f37e2c383c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_624fffd4e87157fd2531d2490eaf1ad73281780d0beb5de89d1b59f37e2c383c->enter($__internal_624fffd4e87157fd2531d2490eaf1ad73281780d0beb5de89d1b59f37e2c383c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        $__internal_e13a7b3e73f889fbecab41b59dfcf09291ddf78c94b766f662b29bfc8b41b928 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e13a7b3e73f889fbecab41b59dfcf09291ddf78c94b766f662b29bfc8b41b928->enter($__internal_e13a7b3e73f889fbecab41b59dfcf09291ddf78c94b766f662b29bfc8b41b928_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        // line 83
        echo "            <section class=\"footer\">
                <div class=\"container-footer\">
                    <div class=\"row\">
                        <div class=\"p-1 col-md-4 col-sm-6\">
                            <h3>Hiyper Links</h3>
                            <ul>
                                <li><a href=\"";
        // line 89
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("blog_index");
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("menu.homepage"), "html", null, true);
        echo "</a></li>
                                <li><a href=\"";
        // line 90
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_post_index");
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("menu.admin"), "html", null, true);
        echo "</a></li>
                                <li><a href=\"";
        // line 91
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("blog_search");
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("menu.search"), "html", null, true);
        echo "</a></li>
                                <li><a href=\"";
        // line 92
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_post_index");
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("menu.post_list"), "html", null, true);
        echo "</a></li>
                                <li><a href=\"";
        // line 93
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("blog_index");
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("menu.back_to_blog"), "html", null, true);
        echo "</a></li>
                            </ul>
                        </div>
                        <div class=\"p-1 col-md-4 col-sm-6\">
                            <h3>Hiyper Links</h3>
                            <ul class=\"web\">
                                <li><i class=\"fab fa-3x fa-facebook\"></i></li>
                                <li><i class=\"fab fa-3x fa-instagram\"></i></li>
                                <li><i class=\"fab fa-3x fa-twitter-square\"></i></li>
                                <li><i class=\"fab fa-3x fa-youtube\"></i></li>
                                <li><i class=\"fab fa-3x fa-linkedin\"></i></li>
                            </ul>
                        </div>
                        <div class=\"p-1 col-md-4 col-sm-12\">
                            <h3>language</h3>
                            <button class=\"btn btn-light dropdown-toggle\" type=\"button\" id=\"dropdownMenuButton\" data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">
                                ";
        // line 109
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("menu.choose_language"), "html", null, true);
        echo "
                            </button>
                            <div class=\"dropdown-menu\" aria-labelledby=\"dropdownMenuButton\">
                                ";
        // line 112
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->env->getExtension('AppBundle\Twig\AppExtension')->getLocales());
        foreach ($context['_seq'] as $context["_key"] => $context["locale"]) {
            // line 113
            echo "                                    <p class=\"dropdown-item\" ";
            if (($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "locale", array()) == $this->getAttribute($context["locale"], "code", array()))) {
                echo "aria-checked=\"true\" class=\"active\"";
            } else {
                echo "aria-checked=\"false\"";
            }
            echo " role=\"menuitem\">
                                        <a href=\"";
            // line 114
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "get", array(0 => "_route", 1 => "blog_index"), "method"), twig_array_merge($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "get", array(0 => "_route_params", 1 => array()), "method"), array("_locale" => $this->getAttribute($context["locale"], "code", array())))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, $this->getAttribute($context["locale"], "name", array())), "html", null, true);
            echo "</a>
                                    </p>
                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['locale'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 117
        echo "                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <footer class=\"bg-dark text-center p-2\" style=\"color:#fff\">
                <div class=\"container\">
                    <div id=\"footer-copyright\">
                        <span>&copy; ";
        // line 125
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, "now", "Y"), "html", null, true);
        echo " - The Symfony Project</span>
                        <span>";
        // line 126
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("mit_license"), "html", null, true);
        echo "</span>
                    </div>
                </div>
            </footer>
        ";
        
        $__internal_e13a7b3e73f889fbecab41b59dfcf09291ddf78c94b766f662b29bfc8b41b928->leave($__internal_e13a7b3e73f889fbecab41b59dfcf09291ddf78c94b766f662b29bfc8b41b928_prof);

        
        $__internal_624fffd4e87157fd2531d2490eaf1ad73281780d0beb5de89d1b59f37e2c383c->leave($__internal_624fffd4e87157fd2531d2490eaf1ad73281780d0beb5de89d1b59f37e2c383c_prof);

    }

    // line 135
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_c5a75f0a786aea07a98822c3a3095012c947bd9428688bd4aeb6e798cd7504d4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c5a75f0a786aea07a98822c3a3095012c947bd9428688bd4aeb6e798cd7504d4->enter($__internal_c5a75f0a786aea07a98822c3a3095012c947bd9428688bd4aeb6e798cd7504d4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_521e90792b909f668db5d8c39dad20bc4ec3715470b3882a5447f1cc8622669c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_521e90792b909f668db5d8c39dad20bc4ec3715470b3882a5447f1cc8622669c->enter($__internal_521e90792b909f668db5d8c39dad20bc4ec3715470b3882a5447f1cc8622669c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 136
        echo "            <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("build/manifest.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 137
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("build/js/common.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 138
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("build/js/app.js"), "html", null, true);
        echo "\"></script>
        ";
        
        $__internal_521e90792b909f668db5d8c39dad20bc4ec3715470b3882a5447f1cc8622669c->leave($__internal_521e90792b909f668db5d8c39dad20bc4ec3715470b3882a5447f1cc8622669c_prof);

        
        $__internal_c5a75f0a786aea07a98822c3a3095012c947bd9428688bd4aeb6e798cd7504d4->leave($__internal_c5a75f0a786aea07a98822c3a3095012c947bd9428688bd4aeb6e798cd7504d4_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  493 => 138,  489 => 137,  484 => 136,  475 => 135,  460 => 126,  456 => 125,  446 => 117,  435 => 114,  426 => 113,  422 => 112,  416 => 109,  395 => 93,  389 => 92,  383 => 91,  377 => 90,  371 => 89,  363 => 83,  354 => 82,  337 => 75,  324 => 77,  321 => 76,  318 => 75,  309 => 74,  299 => 43,  291 => 40,  288 => 39,  286 => 38,  279 => 36,  276 => 35,  267 => 34,  252 => 66,  241 => 63,  232 => 62,  228 => 61,  222 => 58,  211 => 52,  207 => 50,  199 => 47,  196 => 46,  194 => 45,  191 => 44,  189 => 34,  179 => 27,  176 => 26,  167 => 25,  150 => 23,  137 => 17,  128 => 16,  110 => 11,  95 => 144,  92 => 140,  90 => 135,  84 => 131,  82 => 82,  78 => 80,  76 => 74,  72 => 72,  70 => 25,  65 => 23,  59 => 19,  57 => 16,  48 => 12,  44 => 11,  37 => 7,  34 => 6,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#
   This is the base template used as the application layout which contains the
   common elements and decorates all the other templates.
   See https://symfony.com/doc/current/book/templating.html#template-inheritance-and-layouts
#}
<!DOCTYPE html>
<html lang=\"{{ app.request.locale }}\">
    <head>
        <meta charset=\"UTF-8\" />
        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>
        <title>{% block title %}Symfony Demo application{% endblock %}</title>
        <link rel=\"alternate\" type=\"application/rss+xml\" title=\"{{ 'rss.title'|trans }}\" href=\"{{ path('blog_rss') }}\">
        
        <link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css\" integrity=\"sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm\" crossorigin=\"anonymous\">
        <link href=\"https://use.fontawesome.com/releases/v5.0.8/css/all.css\" rel=\"stylesheet\">
        {% block stylesheets %}
            <link rel=\"stylesheet\" href=\"{{ asset('build/css/app.css') }}\">
        {% endblock %}

        <link rel=\"icon\" type=\"image/x-icon\" href=\"https://www.tuwien.ac.at/fileadmin/t/tuwien/downloads/cd/CD_NEU_2009/TU_Logos_2009/TU-Signet.png\" />
    </head>

    <body id=\"{% block body_id %}{% endblock %}\" style=\"background-color: #eee\">

        {% block header %}
            <nav class=\"navbar navbar-expand-lg navbar-dark bg-dark\">
                <a class=\"navbar-brand\" href=\"{{ path('homepage') }}\">CR 14</a>
                <button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarSupportedContent\" aria-controls=\"navbarSupportedContent\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">
                    <span class=\"navbar-toggler-icon\"></span>
                </button>

                <div class=\"collapse navbar-collapse\" id=\"navbarSupportedContent\">
                    <ul class=\"navbar-nav mr-auto\">
                        {% block header_navigation_links %}
                            <li class=\"nav-item active\">
                                <a class=\"nav-link\" href=\"{{ path('blog_index') }}\">{{ 'menu.homepage'|trans }} <span class=\"sr-only\">(current)</span></a>
                            </li>
                        {% if is_granted('ROLE_ADMIN') %}
                            <li class=\"nav-item\">
                                <a class=\"nav-link\" href=\"{{ path('admin_post_index') }}\">{{ 'menu.admin'|trans }}</a>
                            </li>
                        {% endif %}
                        {% endblock %}

                        {% if app.user %}
                            <li class=\"nav-item\">
                                <a class=\"nav-link\" href=\"{{ path('security_logout') }}\">{{ 'menu.logout'|trans }}</a>
                            </li>
                        {% endif %}

                        <li class=\"nav-item\">
                            <a class=\"nav-link\" href=\"{{ path('blog_search') }}\">{{ 'menu.search'|trans }}</a>
                        </li>
                    </ul>

                    <div class=\"dropdown form-inline my-2 my-lg-0\">
                        <button class=\"btn btn-light dropdown-toggle\" type=\"button\" id=\"dropdownMenuButton\" data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">
                            {{ 'menu.choose_language'|trans }}
                        </button>
                        <div class=\"dropdown-menu\" aria-labelledby=\"dropdownMenuButton\">
                            {% for locale in locales() %}
                                <p class=\"dropdown-item\" {% if app.request.locale == locale.code %}aria-checked=\"true\" class=\"active\"{% else %}aria-checked=\"false\"{% endif %} role=\"menuitem\">
                                    <a href=\"{{ path(app.request.get('_route', 'blog_index'), app.request.get('_route_params', [])|merge({_locale: locale.code})) }}\">{{ locale.name|capitalize }}</a>
                                </p>
                            {% endfor %}
                        </div>
                    </div>

                </div>
            </nav>
        {% endblock %}

        <div class=\"body-container\">
            {% block body %}
            {% block main %}{% endblock %}
                <div class=\"container\">
                    {{ include('default/_flash_messages.html.twig') }}
                </div>
            {% endblock %}
        </div>

        {% block footer %}
            <section class=\"footer\">
                <div class=\"container-footer\">
                    <div class=\"row\">
                        <div class=\"p-1 col-md-4 col-sm-6\">
                            <h3>Hiyper Links</h3>
                            <ul>
                                <li><a href=\"{{ path('blog_index') }}\">{{ 'menu.homepage'|trans }}</a></li>
                                <li><a href=\"{{ path('admin_post_index') }}\">{{ 'menu.admin'|trans }}</a></li>
                                <li><a href=\"{{ path('blog_search') }}\">{{ 'menu.search'|trans }}</a></li>
                                <li><a href=\"{{ path('admin_post_index') }}\">{{ 'menu.post_list'|trans }}</a></li>
                                <li><a href=\"{{ path('blog_index') }}\">{{ 'menu.back_to_blog'|trans }}</a></li>
                            </ul>
                        </div>
                        <div class=\"p-1 col-md-4 col-sm-6\">
                            <h3>Hiyper Links</h3>
                            <ul class=\"web\">
                                <li><i class=\"fab fa-3x fa-facebook\"></i></li>
                                <li><i class=\"fab fa-3x fa-instagram\"></i></li>
                                <li><i class=\"fab fa-3x fa-twitter-square\"></i></li>
                                <li><i class=\"fab fa-3x fa-youtube\"></i></li>
                                <li><i class=\"fab fa-3x fa-linkedin\"></i></li>
                            </ul>
                        </div>
                        <div class=\"p-1 col-md-4 col-sm-12\">
                            <h3>language</h3>
                            <button class=\"btn btn-light dropdown-toggle\" type=\"button\" id=\"dropdownMenuButton\" data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">
                                {{ 'menu.choose_language'|trans }}
                            </button>
                            <div class=\"dropdown-menu\" aria-labelledby=\"dropdownMenuButton\">
                                {% for locale in locales() %}
                                    <p class=\"dropdown-item\" {% if app.request.locale == locale.code %}aria-checked=\"true\" class=\"active\"{% else %}aria-checked=\"false\"{% endif %} role=\"menuitem\">
                                        <a href=\"{{ path(app.request.get('_route', 'blog_index'), app.request.get('_route_params', [])|merge({_locale: locale.code})) }}\">{{ locale.name|capitalize }}</a>
                                    </p>
                                {% endfor %}
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <footer class=\"bg-dark text-center p-2\" style=\"color:#fff\">
                <div class=\"container\">
                    <div id=\"footer-copyright\">
                        <span>&copy; {{ 'now'|date('Y') }} - The Symfony Project</span>
                        <span>{{ 'mit_license'|trans }}</span>
                    </div>
                </div>
            </footer>
        {% endblock %}

        <script src=\"https://code.jquery.com/jquery-3.2.1.slim.min.js\" integrity=\"sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN\" crossorigin=\"anonymous\"></script>
        <script src=\"https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js\" integrity=\"sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q\" crossorigin=\"anonymous\"></script>
        <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js\" integrity=\"sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl\" crossorigin=\"anonymous\"></script>
        {% block javascripts %}
            <script src=\"{{ asset('build/manifest.js') }}\"></script>
            <script src=\"{{ asset('build/js/common.js') }}\"></script>
            <script src=\"{{ asset('build/js/app.js') }}\"></script>
        {% endblock %}

        {# it's not mandatory to set the timezone in localizeddate(). This is done to
           avoid errors when the 'intl' PHP extension is not available and the application
           is forced to use the limited \"intl polyfill\", which only supports UTC and GMT #}
        <!-- Page rendered on {{ 'now'|localizeddate('long', 'long', null, 'UTC') }} -->
    </body>
</html>
", "base.html.twig", "C:\\xampp\\htdocs\\Moaz-Sabri-FSWD30-CodeReview14\\app\\Resources\\views\\base.html.twig");
    }
}
