<?php

/* admin/blog/_delete_form.html.twig */
class __TwigTemplate_4453db76db3cbc182770c3a8ba3dfd41a482184b4823567f90e0d0bfb9eee9ae extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_87952999d8ef0b40645dd38664e14ed7927550f50f7fadf018e2c031a2adf8cb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_87952999d8ef0b40645dd38664e14ed7927550f50f7fadf018e2c031a2adf8cb->enter($__internal_87952999d8ef0b40645dd38664e14ed7927550f50f7fadf018e2c031a2adf8cb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "admin/blog/_delete_form.html.twig"));

        $__internal_592b03cb43b462999d50e30cb3ede254203d68b6a5392e14458ef5c85e280eb4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_592b03cb43b462999d50e30cb3ede254203d68b6a5392e14458ef5c85e280eb4->enter($__internal_592b03cb43b462999d50e30cb3ede254203d68b6a5392e14458ef5c85e280eb4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "admin/blog/_delete_form.html.twig"));

        // line 1
        echo twig_include($this->env, $context, "blog/_delete_post_confirmation.html.twig");
        echo "
<form action=\"";
        // line 2
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getUrl("admin_post_delete", array("id" => $this->getAttribute(($context["post"] ?? $this->getContext($context, "post")), "id", array()))), "html", null, true);
        echo "\" method=\"post\">
    <input type=\"hidden\" name=\"token\" value=\"";
        // line 3
        echo twig_escape_filter($this->env, $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderCsrfToken("delete"), "html", null, true);
        echo "\" />
    <button type=\"submit\" class=\"btn btn-lg btn-block btn-danger\">
        ";
        // line 5
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("action.delete_post"), "html", null, true);
        echo "
    </button>
</form>

";
        
        $__internal_87952999d8ef0b40645dd38664e14ed7927550f50f7fadf018e2c031a2adf8cb->leave($__internal_87952999d8ef0b40645dd38664e14ed7927550f50f7fadf018e2c031a2adf8cb_prof);

        
        $__internal_592b03cb43b462999d50e30cb3ede254203d68b6a5392e14458ef5c85e280eb4->leave($__internal_592b03cb43b462999d50e30cb3ede254203d68b6a5392e14458ef5c85e280eb4_prof);

    }

    public function getTemplateName()
    {
        return "admin/blog/_delete_form.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  38 => 5,  33 => 3,  29 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('blog/_delete_post_confirmation.html.twig') }}
<form action=\"{{ url('admin_post_delete', {id: post.id}) }}\" method=\"post\">
    <input type=\"hidden\" name=\"token\" value=\"{{ csrf_token('delete') }}\" />
    <button type=\"submit\" class=\"btn btn-lg btn-block btn-danger\">
        {{ 'action.delete_post'|trans }}
    </button>
</form>

", "admin/blog/_delete_form.html.twig", "C:\\xampp\\htdocs\\symfony_demo\\app\\Resources\\views\\admin\\blog\\_delete_form.html.twig");
    }
}
