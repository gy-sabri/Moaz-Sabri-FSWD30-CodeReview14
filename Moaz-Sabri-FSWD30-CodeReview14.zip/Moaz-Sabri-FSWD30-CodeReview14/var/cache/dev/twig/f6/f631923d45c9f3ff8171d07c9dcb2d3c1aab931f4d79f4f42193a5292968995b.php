<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_01f5c66442bec9644a65681d18df585ec11be23846398f2d290de22b876e0dad extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_15a0905c225d8518f6a8148c747a4b315d4c9aab5a9129503e1ebea008f04747 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_15a0905c225d8518f6a8148c747a4b315d4c9aab5a9129503e1ebea008f04747->enter($__internal_15a0905c225d8518f6a8148c747a4b315d4c9aab5a9129503e1ebea008f04747_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_d255fa797b1d58db5f4833ad45d23dfb23a38395349000ef2f7bf19882adbea3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d255fa797b1d58db5f4833ad45d23dfb23a38395349000ef2f7bf19882adbea3->enter($__internal_d255fa797b1d58db5f4833ad45d23dfb23a38395349000ef2f7bf19882adbea3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_15a0905c225d8518f6a8148c747a4b315d4c9aab5a9129503e1ebea008f04747->leave($__internal_15a0905c225d8518f6a8148c747a4b315d4c9aab5a9129503e1ebea008f04747_prof);

        
        $__internal_d255fa797b1d58db5f4833ad45d23dfb23a38395349000ef2f7bf19882adbea3->leave($__internal_d255fa797b1d58db5f4833ad45d23dfb23a38395349000ef2f7bf19882adbea3_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_0483ebfb70770a3c62cf4695792444712e063e257467f701c7cc48bc04406065 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0483ebfb70770a3c62cf4695792444712e063e257467f701c7cc48bc04406065->enter($__internal_0483ebfb70770a3c62cf4695792444712e063e257467f701c7cc48bc04406065_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_152cad8a664e6120001de742eba56c38919824fe06cb8a366ecaddaa486b00cf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_152cad8a664e6120001de742eba56c38919824fe06cb8a366ecaddaa486b00cf->enter($__internal_152cad8a664e6120001de742eba56c38919824fe06cb8a366ecaddaa486b00cf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_152cad8a664e6120001de742eba56c38919824fe06cb8a366ecaddaa486b00cf->leave($__internal_152cad8a664e6120001de742eba56c38919824fe06cb8a366ecaddaa486b00cf_prof);

        
        $__internal_0483ebfb70770a3c62cf4695792444712e063e257467f701c7cc48bc04406065->leave($__internal_0483ebfb70770a3c62cf4695792444712e063e257467f701c7cc48bc04406065_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_a1306b103946d3de16386669aafce016a6051555ce88afc5bb6870121f6054aa = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a1306b103946d3de16386669aafce016a6051555ce88afc5bb6870121f6054aa->enter($__internal_a1306b103946d3de16386669aafce016a6051555ce88afc5bb6870121f6054aa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_ef5142736d86177d3167ecaf3353fcc50d8a7354957401ae747295e954c540fe = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ef5142736d86177d3167ecaf3353fcc50d8a7354957401ae747295e954c540fe->enter($__internal_ef5142736d86177d3167ecaf3353fcc50d8a7354957401ae747295e954c540fe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_ef5142736d86177d3167ecaf3353fcc50d8a7354957401ae747295e954c540fe->leave($__internal_ef5142736d86177d3167ecaf3353fcc50d8a7354957401ae747295e954c540fe_prof);

        
        $__internal_a1306b103946d3de16386669aafce016a6051555ce88afc5bb6870121f6054aa->leave($__internal_a1306b103946d3de16386669aafce016a6051555ce88afc5bb6870121f6054aa_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_f319df771a6cfeb935ef314c5d2bf48ca4293bbd53156e75fdc1d1d3729f308d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f319df771a6cfeb935ef314c5d2bf48ca4293bbd53156e75fdc1d1d3729f308d->enter($__internal_f319df771a6cfeb935ef314c5d2bf48ca4293bbd53156e75fdc1d1d3729f308d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_604fe8bb811612b811a03d03a1ef78a29a14aac834b87ec90bad4dd00bb2e557 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_604fe8bb811612b811a03d03a1ef78a29a14aac834b87ec90bad4dd00bb2e557->enter($__internal_604fe8bb811612b811a03d03a1ef78a29a14aac834b87ec90bad4dd00bb2e557_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_604fe8bb811612b811a03d03a1ef78a29a14aac834b87ec90bad4dd00bb2e557->leave($__internal_604fe8bb811612b811a03d03a1ef78a29a14aac834b87ec90bad4dd00bb2e557_prof);

        
        $__internal_f319df771a6cfeb935ef314c5d2bf48ca4293bbd53156e75fdc1d1d3729f308d->leave($__internal_f319df771a6cfeb935ef314c5d2bf48ca4293bbd53156e75fdc1d1d3729f308d_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "C:\\xampp\\htdocs\\symfony_demo\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\router.html.twig");
    }
}
